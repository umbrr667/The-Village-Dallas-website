import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { useSmoothScroll } from "@/hooks/useLenis";
import { Preloader } from "@/components/site/Preloader";
import { CursorGlow } from "@/components/site/CursorGlow";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Skills } from "@/components/site/Skills";
import { Projects } from "@/components/site/Projects";
import { Footer } from "@/components/site/Footer";

const TechLogos = lazy(() =>
  import("@/components/site/TechLogos").then((m) => ({ default: m.TechLogos })),
);
const LiveDemos = lazy(() =>
  import("@/components/site/LiveDemos").then((m) => ({ default: m.LiveDemos })),
);
const Services = lazy(() =>
  import("@/components/site/Services").then((m) => ({ default: m.Services })),
);
const WorkflowTimeline = lazy(() =>
  import("@/components/site/WorkflowTimeline").then((m) => ({
    default: m.WorkflowTimeline,
  })),
);
const TechStack = lazy(() =>
  import("@/components/site/TechStack").then((m) => ({ default: m.TechStack })),
);
const Resume = lazy(() =>
  import("@/components/site/Resume").then((m) => ({ default: m.Resume })),
);
const Certifications = lazy(() =>
  import("@/components/site/Certifications").then((m) => ({ default: m.Certifications })),
);
const Leadership = lazy(() =>
  import("@/components/site/Leadership").then((m) => ({ default: m.Leadership })),
);
const Contact = lazy(() =>
  import("@/components/site/Contact").then((m) => ({ default: m.Contact })),
);

const title = "Umbar Gul Naz — AI Automation Engineer & Python Developer";
const description =
  "AI Automation Engineer building AI chatbots, voice agents, email automation and document intelligence with Python, LangChain and the Groq API.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  useSmoothScroll();

  return (
    <>
      <Preloader />
      <CursorGlow />
      <Nav />
      <main>
        <h1 className="sr-only">
          Umbar Gul Naz — AI Automation Engineer, Python Developer, AI Chatbot and Voice
          Agent Builder
        </h1>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Suspense fallback={null}>
          <TechLogos />
          <LiveDemos />
          <Services />
          <WorkflowTimeline />
          <TechStack />
          <Resume />
          <Certifications />
          <Leadership />
          <Contact />
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
