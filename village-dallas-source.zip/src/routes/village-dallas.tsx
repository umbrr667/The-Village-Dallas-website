import { createFileRoute } from "@tanstack/react-router";
import { useSmoothScroll } from "@/hooks/useLenis";
import { VillagePreloader } from "@/components/village/VillagePreloader";
import { VillageCursor } from "@/components/village/VillageCursor";
import { VillageNav } from "@/components/village/VillageNav";
import { VillageHero } from "@/components/village/VillageHero";
import { VillageBooking } from "@/components/village/VillageBooking";
import { VillageAbout } from "@/components/village/VillageAbout";
import { VillageRooms } from "@/components/village/VillageRooms";
import { VillageAmenities } from "@/components/village/VillageAmenities";
import { VillageDining } from "@/components/village/VillageDining";
import { VillageGallery } from "@/components/village/VillageGallery";
import { VillageExperiences } from "@/components/village/VillageExperiences";
import { VillageReviews } from "@/components/village/VillageReviews";
import { VillageLocation } from "@/components/village/VillageLocation";
import { VillageFaq } from "@/components/village/VillageFaq";
import { VillageContact } from "@/components/village/VillageContact";
import { VillageFooter } from "@/components/village/VillageFooter";

const TITLE = "The Village Dallas — Luxury Residential Resort Concept";
const DESC =
  "A cinematic redesign concept for The Village Dallas: luxury suites, rooftop infinity pool, spa, hearth-fired dining and 24-hour concierge in the heart of Dallas.";

export const Route = createFileRoute("/village-dallas")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: VillageDallasPage,
});

function VillageDallasPage() {
  useSmoothScroll();

  return (
    <div className="village relative min-h-screen overflow-x-clip">
      <VillagePreloader />
      <VillageCursor />
      <VillageNav />
      <main>
        
        <VillageHero />
        <VillageBooking />
        <VillageAbout />
        <VillageRooms />
        <VillageAmenities />
        <VillageDining />
        <VillageGallery />
        <VillageExperiences />
        <VillageReviews />
        <VillageLocation />
        <VillageFaq />
        <VillageContact />
      </main>
      <VillageFooter />
    </div>
  );
}
