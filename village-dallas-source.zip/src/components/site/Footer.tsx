import { Download, Github, Linkedin, Mail } from "lucide-react";
import {
  EMAIL,
  GITHUB_URL,
  LINKEDIN_URL,
  NAME,
  NAV_LINKS,
  RESUME_URL,
} from "@/lib/profile";

export function Footer() {
  return (
    <footer className="relative border-t border-border px-5 py-12">
      <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-[1fr_auto]">
        <div>
          <a href="#top" className="flex min-w-0 items-center gap-2.5">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-sm font-bold text-primary-foreground [background-image:var(--gradient-neon)]">
              UG
            </span>
            <span className="font-display text-sm font-semibold">{NAME}</span>
          </a>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">
            AI Automation Engineer · AI Chatbot &amp; LLM Developer · Python Developer.
          </p>
          <nav className="mt-6 flex flex-wrap gap-x-5 gap-y-2">
            {NAV_LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {l.label}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex flex-wrap items-start gap-2">
          <a
            href={GITHUB_URL}
            target="_blank"
            rel="noreferrer"
            aria-label="GitHub"
            className="glass grid h-11 w-11 place-items-center rounded-full transition-colors hover:text-accent"
          >
            <Github className="h-4 w-4" />
          </a>
          <a
            href={LINKEDIN_URL}
            target="_blank"
            rel="noreferrer"
            aria-label="LinkedIn"
            className="glass grid h-11 w-11 place-items-center rounded-full transition-colors hover:text-accent"
          >
            <Linkedin className="h-4 w-4" />
          </a>
          <a
            href={`mailto:${EMAIL}`}
            aria-label="Email"
            className="glass grid h-11 w-11 place-items-center rounded-full transition-colors hover:text-accent"
          >
            <Mail className="h-4 w-4" />
          </a>
          <a
            href={RESUME_URL}
            download="Umbar_Gul_Naz_Resume.pdf"
            className="glass inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold"
          >
            <Download className="h-4 w-4" /> Resume
          </a>
        </div>
      </div>

      <div className="neon-divider mx-auto mt-10 max-w-6xl" />
      <p className="mx-auto mt-6 max-w-6xl text-xs text-muted-foreground">
        © {new Date().getFullYear()} {NAME}. All rights reserved.
      </p>
    </footer>
  );
}
