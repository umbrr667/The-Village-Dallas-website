import { Brain, Code2, Layers, Wrench } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { SKILL_GROUPS } from "@/lib/profile";

const icons = { code: Code2, brain: Brain, layers: Layers, wrench: Wrench } as const;
const tones = {
  primary: "oklch(0.623 0.214 259.8)",
  secondary: "oklch(0.606 0.25 292.7)",
  accent: "oklch(0.696 0.17 162.5)",
} as const;

export function Skills() {
  return (
    <section id="skills" className="section-pad relative">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Skills"
          title="A stack tuned for AI automation"
          subtitle="Everything below is a tool I actively build with — no filler."
        />

        <div className="grid gap-6 md:grid-cols-2">
          {SKILL_GROUPS.map((g, i) => {
            const Icon = icons[g.icon as keyof typeof icons];
            const tone = tones[g.tone];
            return (
              <Reveal key={g.title} delay={i * 0.08}>
                <article className="glass glass-hover group relative h-full overflow-hidden rounded-3xl p-7">
                  <div
                    className="absolute -top-16 -right-16 h-44 w-44 rounded-full opacity-30 blur-3xl transition-opacity duration-500 group-hover:opacity-70"
                    style={{ background: tone }}
                  />
                  <div className="relative flex items-center gap-4">
                    <span
                      className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl border"
                      style={{
                        borderColor: `${tone}`,
                        background: `color-mix(in oklab, ${tone} 14%, transparent)`,
                        boxShadow: `0 0 28px -8px ${tone}`,
                      }}
                    >
                      <Icon className="h-6 w-6" style={{ color: tone }} />
                    </span>
                    <h3 className="text-xl font-semibold">{g.title}</h3>
                  </div>

                  <ul className="relative mt-6 flex flex-wrap gap-2">
                    {g.items.map((it) => (
                      <li
                        key={it}
                        className="rounded-full border border-border bg-secondary/40 px-3.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-accent/50 hover:text-foreground"
                      >
                        {it}
                      </li>
                    ))}
                  </ul>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
