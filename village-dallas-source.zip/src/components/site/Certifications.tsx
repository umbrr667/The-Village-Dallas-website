import { Award } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { CERTIFICATIONS } from "@/lib/profile";

export function Certifications() {
  return (
    <section id="certifications" className="section-pad relative">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Certifications"
          title="Training that backs the work"
          subtitle="Completed programs in Python, AI automation and digital skills."
        />

        <div className="grid gap-5 sm:grid-cols-2">
          {CERTIFICATIONS.map((c, i) => (
            <Reveal key={c.title} delay={i * 0.07}>
              <article className="glass glass-hover group relative h-full overflow-hidden rounded-3xl p-7">
                <div className="absolute -top-14 -right-14 h-40 w-40 rounded-full bg-primary/20 opacity-40 blur-3xl transition-opacity duration-500 group-hover:opacity-80" />
                <div className="relative flex items-start gap-4">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border border-accent/40 bg-accent/10 text-accent">
                    <Award className="h-5 w-5" />
                  </span>
                  <div className="min-w-0">
                    <h3 className="text-base leading-snug font-semibold">{c.title}</h3>
                    <p className="mt-1.5 text-sm text-muted-foreground">{c.issuer}</p>
                    <span className="mt-3 inline-block rounded-full border border-border bg-secondary/40 px-3 py-1 text-[11px] tracking-[0.12em] text-muted-foreground uppercase">
                      {c.detail}
                    </span>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
