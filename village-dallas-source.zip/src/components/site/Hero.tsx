import { lazy, Suspense, useEffect, useState } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowDown, Download, Mail, PlayCircle, Sparkles } from "lucide-react";
import { MagneticButton } from "./primitives";
import {
  INTRO,
  NAME,
  PORTRAIT_URL,
  RESUME_URL,
  ROLE,
  TYPING_PHRASES,
} from "@/lib/profile";

const Scene3D = lazy(() => import("./Scene3D"));

function Typewriter() {
  const [index, setIndex] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const full = TYPING_PHRASES[index] ?? "";
    const delay = deleting ? 32 : text === full ? 1700 : 62;
    const timer = setTimeout(() => {
      if (!deleting && text === full) return setDeleting(true);
      if (deleting && text === "") {
        setDeleting(false);
        setIndex((i) => (i + 1) % TYPING_PHRASES.length);
        return;
      }
      setText(deleting ? full.slice(0, text.length - 1) : full.slice(0, text.length + 1));
    }, delay);
    return () => clearTimeout(timer);
  }, [text, deleting, index]);

  return (
    <span className="text-gradient font-display">
      {text}
      <span className="ml-0.5 inline-block h-[1em] w-[2px] translate-y-[0.12em] animate-pulse bg-accent align-middle" />
    </span>
  );
}

function NeuralNet() {
  const nodes = Array.from({ length: 24 }, (_, i) => ({
    x: 6 + ((i * 37) % 88),
    y: 8 + ((i * 53) % 84),
    d: (i % 7) * 0.4,
  }));
  return (
    <svg
      aria-hidden
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
      className="absolute inset-0 h-full w-full opacity-40"
    >
      {nodes.map((n, i) =>
        nodes.slice(i + 1, i + 3).map((m, j) => (
          <line
            key={`${i}-${j}`}
            x1={n.x}
            y1={n.y}
            x2={m.x}
            y2={m.y}
            stroke="oklch(0.623 0.214 259.8 / 32%)"
            strokeWidth="0.15"
          />
        )),
      )}
      {nodes.map((n, i) => (
        <circle
          key={i}
          cx={n.x}
          cy={n.y}
          r="0.55"
          fill="oklch(0.696 0.17 162.5)"
          className="animate-pulse-glow"
          style={{ animationDelay: `${n.d}s` }}
        />
      ))}
    </svg>
  );
}

function Particles() {
  const dots = Array.from({ length: 18 }, (_, i) => ({
    left: `${(i * 13.7) % 96}%`,
    top: `${(i * 29.3) % 92}%`,
    delay: (i % 9) * 0.7,
    dur: 6 + (i % 5) * 1.6,
    size: 2 + (i % 3),
  }));
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {dots.map((d, i) => (
        <motion.span
          key={i}
          className="absolute rounded-full bg-accent/60"
          style={{ left: d.left, top: d.top, width: d.size, height: d.size }}
          animate={{ y: [0, -26, 0], opacity: [0.15, 0.8, 0.15] }}
          transition={{ duration: d.dur, delay: d.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}
    </div>
  );
}

export function Hero() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 700], [0, 130]);
  const opacity = useTransform(scrollY, [0, 520], [1, 0]);

  return (
    <section id="top" className="relative flex min-h-screen items-center overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <motion.div
          className="absolute top-[-22%] left-1/2 h-[70vh] w-[70vw] -translate-x-1/2 rounded-full bg-primary/20 blur-[150px]"
          animate={{ scale: [1, 1.12, 1], opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute right-[-12%] bottom-0 h-[52vh] w-[46vw] rounded-full bg-neon-purple/18 blur-[160px]"
          animate={{ scale: [1.1, 1, 1.1], opacity: [0.6, 0.95, 0.6] }}
          transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-[10%] left-[-8%] h-[36vh] w-[34vw] rounded-full bg-accent/12 blur-[140px]"
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 16, repeat: Infinity, ease: "easeInOut" }}
        />
        <NeuralNet />
        <Particles />
      </div>

      <div className="absolute inset-0">
        <ClientOnly fallback={null}>
          <Suspense fallback={null}>
            <Scene3D />
          </Suspense>
        </ClientOnly>
      </div>

      <motion.div
        style={{ y, opacity }}
        className="relative z-10 mx-auto grid w-full max-w-6xl items-center gap-14 px-5 pt-32 pb-24 lg:grid-cols-[1.12fr_0.88fr]"
      >
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.7, duration: 0.8 }}
            className="glass inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs tracking-[0.2em] text-accent uppercase"
          >
            <Sparkles className="h-3.5 w-3.5" /> Open to AI automation internships & projects
          </motion.span>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.8, duration: 0.7 }}
            className="mt-7 text-lg font-medium text-muted-foreground"
          >
            Hi, I&apos;m
          </motion.p>

          <h1 className="mt-2 text-5xl leading-[0.95] font-bold text-balance sm:text-6xl lg:text-7xl">
            {NAME.split(" ").map((word, i) => (
              <motion.span
                key={word}
                initial={{ opacity: 0, y: 44, filter: "blur(10px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                transition={{ delay: 2 + i * 0.12, duration: 0.85 }}
                className="inline-block whitespace-pre"
              >
                <span className="text-gradient">{word}</span>
                {i < 2 ? " " : ""}
              </motion.span>
            ))}
          </h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.4, duration: 0.9 }}
            className="mt-5 text-sm tracking-[0.16em] text-muted-foreground uppercase sm:text-[0.95rem]"
          >
            {ROLE}
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.55, duration: 0.9 }}
            className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg"
          >
            {INTRO}
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.7, duration: 0.9 }}
            className="mt-7 text-2xl font-semibold sm:text-3xl"
          >
            <Typewriter />
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2.8, duration: 0.9 }}
            className="mt-2 text-sm text-muted-foreground"
          >
            Building AI Solutions That Automate Businesses.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2.95, duration: 0.9 }}
            className="mt-10 flex flex-wrap gap-3"
          >
            <MagneticButton href="#demos">
              <PlayCircle className="h-4 w-4" /> Watch Live Demos
            </MagneticButton>
            <MagneticButton href="#projects" variant="ghost">
              View Projects <ArrowDown className="h-4 w-4" />
            </MagneticButton>
            <MagneticButton href={RESUME_URL} download variant="ghost">
              <Download className="h-4 w-4" /> Download Resume
            </MagneticButton>
            <MagneticButton href="#contact" variant="ghost">
              <Mail className="h-4 w-4" /> Contact Me
            </MagneticButton>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 2.05, duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto w-full max-w-sm"
        >
          <motion.div
            aria-hidden
            className="absolute -inset-6 -z-10 rounded-[3rem] opacity-70 blur-[70px] [background-image:var(--gradient-neon)]"
            animate={{ opacity: [0.4, 0.75, 0.4] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          />
          <div className="animate-float glass relative overflow-hidden rounded-[2rem] p-3">
            <div
              aria-hidden
              className="pointer-events-none absolute inset-0 rounded-[2rem] border border-primary/30"
            />
            <img
              src={PORTRAIT_URL}
              alt={`Professional portrait of ${NAME}, AI Automation Engineer`}
              width={1024}
              height={1080}
              className="w-full rounded-[1.6rem] object-cover"
            />
            <div className="pointer-events-none absolute inset-3 rounded-[1.6rem] [background-image:linear-gradient(160deg,oklch(0.623_0.214_259.8/12%),transparent_45%,oklch(0.606_0.25_292.7/16%))]" />
          </div>

          {[
            { label: "Python", cls: "-left-4 top-10" },
            { label: "LangChain", cls: "-right-5 top-1/3" },
            { label: "Groq API", cls: "-left-6 bottom-16" },
          ].map((chip, i) => (
            <motion.span
              key={chip.label}
              className={`glass absolute ${chip.cls} rounded-full px-3 py-1.5 text-[11px] font-medium text-accent`}
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 5 + i, repeat: Infinity, ease: "easeInOut", delay: i * 0.6 }}
            >
              {chip.label}
            </motion.span>
          ))}
        </motion.div>
      </motion.div>

      <div className="absolute inset-x-0 bottom-8 flex justify-center">
        <motion.a
          href="#about"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2.2, repeat: Infinity }}
          className="text-xs tracking-[0.35em] text-muted-foreground uppercase"
        >
          Scroll
        </motion.a>
      </div>
    </section>
  );
}
