import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";

export function Preloader() {
  const [done, setDone] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(100, ((t - start) / 1500) * 100);
      setProgress(p);
      if (p < 100) raf = requestAnimationFrame(tick);
      else setTimeout(() => setDone(true), 250);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background"
          exit={{ opacity: 0, filter: "blur(14px)" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="relative grid h-32 w-32 place-items-center">
            <div
              className="animate-spin-slow absolute inset-0 rounded-full border border-primary/40 border-t-accent"
              style={{ ["--spin-duration" as string]: "2.4s" }}
            />
            <div
              className="animate-spin-slow absolute inset-4 rounded-full border border-accent/30 border-b-primary"
              style={{ ["--spin-duration" as string]: "3.6s" }}
            />
            <span className="text-gradient font-display text-2xl font-bold">UG</span>
          </div>
          <div className="mt-10 h-px w-56 overflow-hidden bg-border">
            <div
              className="h-full [background-image:var(--gradient-neon)]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-4 text-xs tracking-[0.4em] text-muted-foreground uppercase">
            Initializing {Math.round(progress)}%
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}