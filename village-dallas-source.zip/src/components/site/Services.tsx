import {
  Bot,
  Brain,
  Building2,
  FileText,
  LayoutTemplate,
  Mail,
  Mic,
  Monitor,
  Sparkles,
  Workflow,
} from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { SERVICES } from "@/lib/profile";

const icons = {
  bot: Bot,
  mic: Mic,
  mail: Mail,
  fileText: FileText,
  workflow: Workflow,
  building: Building2,
  layout: LayoutTemplate,
  monitor: Monitor,
  sparkles: Sparkles,
  brain: Brain,
} as const;

export function Services() {
  return (
    <section id="services" className="section-pad relative">
      <div className="pointer-events-none absolute top-1/4 left-1/4 h-80 w-80 rounded-full bg-accent/8 blur-[140px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Services"
          title="AI Solutions I Build"
          subtitle="Practical, deployable AI and automation work — the things I can build for your business."
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => {
            const Icon = icons[s.icon as keyof typeof icons];
            return (
              <Reveal key={s.title} delay={i * 0.05}>
                <article className="glass glass-hover group h-full rounded-3xl p-6">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl border border-primary/30 bg-primary/10 text-primary transition-colors duration-500 group-hover:border-accent/50 group-hover:text-accent">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-5 text-base font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {s.desc}
                  </p>
                </article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
