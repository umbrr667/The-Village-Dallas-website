import { logoUrl } from "@/lib/techLogos";

export function TechBadge({ name, size = "sm" }: { name: string; size?: "sm" | "md" }) {
  const src = logoUrl(name);
  const pad = size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs";
  const icon = size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/40 ${pad} text-muted-foreground transition-all duration-300 hover:-translate-y-0.5 hover:border-accent/50 hover:text-foreground hover:shadow-[var(--shadow-neon)]`}
    >
      {src ? (
        <img
          src={src}
          alt=""
          aria-hidden
          loading="lazy"
          width={16}
          height={16}
          className={`${icon} shrink-0`}
        />
      ) : (
        <span
          aria-hidden
          className="grid h-3.5 w-3.5 shrink-0 place-items-center rounded-[4px] bg-accent/20 text-[8px] font-bold text-accent"
        >
          {name.charAt(0)}
        </span>
      )}
      {name}
    </span>
  );
}
