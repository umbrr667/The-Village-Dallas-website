import { motion } from "motion/react";
import { Reveal, SectionHeading } from "./primitives";
import { TECH_LOGOS } from "@/lib/techLogos";

export function TechLogos() {
  return (
    <section id="technologies" className="section-pad relative scroll-mt-24">
      <div className="pointer-events-none absolute inset-x-0 top-1/3 mx-auto h-80 w-[60%] rounded-full bg-neon-purple/10 blur-[150px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Technologies"
          title="Tools I build with every day"
          subtitle="The languages, frameworks and platforms behind my AI automation work."
        />

        <div className="grid grid-cols-3 gap-4 sm:grid-cols-4 lg:grid-cols-5">
          {TECH_LOGOS.map((t, i) => (
            <Reveal key={t.name} delay={(i % 5) * 0.05} y={22}>
              <motion.article
                whileHover={{ y: -6, scale: 1.03 }}
                transition={{ type: "spring", stiffness: 260, damping: 18 }}
                className="glass group relative flex h-full flex-col items-center gap-3 overflow-hidden rounded-3xl p-5 text-center transition-colors duration-500 hover:border-accent/50 hover:shadow-[var(--shadow-neon)]"
              >
                <span
                  aria-hidden
                  className="pointer-events-none absolute -top-12 left-1/2 h-24 w-24 -translate-x-1/2 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-60 [background-image:var(--gradient-neon)]"
                />
                <span className="relative grid h-12 w-12 place-items-center rounded-2xl border border-border bg-secondary/40 transition-transform duration-500 group-hover:scale-110">
                  {t.slug || t.src ? (
                    <img
                      src={
                        t.src ??
                        `https://cdn.simpleicons.org/${t.slug}${t.color ? `/${t.color}` : ""}`
                      }
                      alt={`${t.name} logo`}
                      loading="lazy"
                      width={28}
                      height={28}
                      className="h-7 w-7"
                    />
                  ) : (
                    <span className="text-gradient font-display text-base font-bold">
                      {t.name.slice(0, 2)}
                    </span>
                  )}
                </span>
                <span className="relative text-xs font-semibold">{t.name}</span>
                <span className="relative text-[11px] leading-snug text-muted-foreground opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                  {t.note}
                </span>
              </motion.article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
