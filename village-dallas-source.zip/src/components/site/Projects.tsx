import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, Github, PlayCircle, X } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { TechBadge } from "./TechBadge";
import { GITHUB_URL, PROJECTS, type Project } from "@/lib/profile";

export function Projects() {
  const [active, setActive] = useState<Project | null>(null);

  return (
    <section id="projects" className="section-pad relative">
      <div className="pointer-events-none absolute top-1/4 left-0 h-96 w-96 rounded-full bg-primary/10 blur-[140px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Projects"
          title="AI tools I have actually built"
          subtitle="Open any project for the problem it solves, the stack and the feature set."
        />

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {PROJECTS.map((p, i) => (
            <Reveal key={p.id} delay={i * 0.06}>
              <article className="glass glass-hover group flex h-full w-full flex-col overflow-hidden rounded-3xl text-left transition-transform duration-500 hover:-translate-y-1.5 hover:shadow-[var(--shadow-neon)]">
                <div className="relative aspect-16/10 overflow-hidden">
                  <img
                    src={p.image}
                    alt={`${p.title} interface preview`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-background via-background/30 to-transparent" />
                  <span className="glass absolute top-4 left-4 rounded-full px-3 py-1 text-[11px] tracking-[0.15em] text-accent uppercase">
                    {p.tag}
                  </span>
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <div className="flex min-w-0 items-start justify-between gap-3">
                    <h3 className="text-lg leading-snug font-semibold">{p.title}</h3>
                    <ArrowUpRight className="mt-1 h-5 w-5 shrink-0 text-accent transition-transform duration-500 group-hover:translate-x-1 group-hover:-translate-y-1" />
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {p.summary}
                  </p>
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {p.tech.map((t) => (
                      <li key={t}>
                        <TechBadge name={t} />
                      </li>
                    ))}
                  </ul>
                  <div className="mt-5 flex flex-wrap gap-2 pt-1">
                    <a
                      href={GITHUB_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="glass inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold"
                    >
                      <Github className="h-3.5 w-3.5" /> GitHub
                    </a>
                    {p.video ? (
                      <a
                        href="#demos"
                        className="glass inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold text-accent"
                      >
                        <PlayCircle className="h-3.5 w-3.5" /> Watch Demo
                      </a>
                    ) : null}
                    <button
                      onClick={() => setActive(p)}
                      className="ml-auto inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold text-primary-foreground [background-image:var(--gradient-neon)]"
                    >
                      Project Details
                    </button>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-60 flex items-start justify-center overflow-y-auto bg-background/80 p-4 backdrop-blur-xl sm:p-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            role="dialog"
            aria-modal="true"
            aria-label={`${active.title} details`}
          >
            <motion.div
              initial={{ opacity: 0, y: 40, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.98 }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="glass my-auto w-full max-w-3xl overflow-hidden rounded-[2rem]"
            >
              <div className="relative">
                <img
                  src={active.image}
                  alt={`${active.title} cover`}
                  loading="lazy"
                  className="aspect-16/9 w-full object-cover"
                />
                <div className="absolute inset-0 bg-linear-to-t from-card to-transparent" />
                <button
                  onClick={() => setActive(null)}
                  aria-label="Close project"
                  className="glass absolute top-4 right-4 grid h-10 w-10 place-items-center rounded-full"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="p-7 sm:p-9">
                <p className="text-xs tracking-[0.25em] text-accent uppercase">
                  {active.tag}
                </p>
                <h3 className="mt-3 text-3xl font-bold">{active.title}</h3>

                <div className="mt-6 rounded-2xl border border-border bg-secondary/30 p-5">
                  <p className="text-xs font-semibold tracking-[0.2em] text-accent uppercase">
                    Problem solved
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {active.problem}
                  </p>
                </div>

                <p className="mt-6 text-xs font-semibold tracking-[0.2em] uppercase">
                  Project overview
                </p>
                <p className="mt-2 leading-relaxed text-muted-foreground">
                  {active.overview}
                </p>

                <div className="mt-7 grid gap-7 sm:grid-cols-2">
                  <div>
                    <h4 className="text-sm font-semibold tracking-[0.2em] uppercase">
                      Technologies
                    </h4>
                    <ul className="mt-3 flex flex-wrap gap-2">
                      {active.tech.map((t) => (
                        <li key={t}>
                          <TechBadge name={t} size="md" />
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold tracking-[0.2em] uppercase">
                      Features
                    </h4>
                    <ul className="mt-3 space-y-2">
                      {active.features.map((f) => (
                        <li key={f} className="flex gap-2.5 text-sm text-muted-foreground">
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap gap-3">
                  <a
                    href={GITHUB_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground [background-image:var(--gradient-neon)]"
                  >
                    <Github className="h-4 w-4" /> GitHub
                  </a>
                  {active.video ? (
                    <a
                      href="#demos"
                      onClick={() => setActive(null)}
                      className="glass inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
                    >
                      <PlayCircle className="h-4 w-4" /> Watch Demo
                    </a>
                  ) : null}
                  <a
                    href="#contact"
                    onClick={() => setActive(null)}
                    className="glass inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold"
                  >
                    Discuss this project
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
