import { Mic2, Sparkles, Trophy, Users } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { LEADERSHIP } from "@/lib/profile";

const icons = [Trophy, Trophy, Trophy, Mic2, Sparkles, Mic2, Users];

export function Leadership() {
  return (
    <section id="leadership" className="section-pad relative scroll-mt-24">
      <div className="pointer-events-none absolute bottom-0 left-1/3 h-80 w-80 rounded-full bg-neon-purple/10 blur-[140px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Leadership & activities"
          title="Beyond the code"
          subtitle="Debate, public speaking and event hosting alongside the engineering."
        />

        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {LEADERSHIP.map((item, i) => {
            const Icon = icons[i] ?? Users;
            return (
              <Reveal key={item} delay={i * 0.06}>
                <li className="glass glass-hover flex h-full items-start gap-4 rounded-3xl p-6">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-primary/30 bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="text-sm leading-relaxed font-medium">{item}</span>
                </li>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
