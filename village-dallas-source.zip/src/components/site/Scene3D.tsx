import { Canvas, useFrame } from "@react-three/fiber";
import { Icosahedron, Points, PointMaterial, Torus } from "@react-three/drei";
import { useMemo, useRef } from "react";
import type { Group, Points as ThreePoints } from "three";

function ParticleField() {
  const ref = useRef<ThreePoints>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(1800 * 3);
    for (let i = 0; i < arr.length; i += 3) {
      const r = 4 + Math.random() * 7;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      arr[i] = r * Math.sin(phi) * Math.cos(theta);
      arr[i + 1] = r * Math.sin(phi) * Math.sin(theta);
      arr[i + 2] = r * Math.cos(phi);
    }
    return arr;
  }, []);

  useFrame((state, delta) => {
    if (!ref.current) return;
    ref.current.rotation.y += delta * 0.04;
    ref.current.rotation.x =
      Math.sin(state.clock.elapsedTime * 0.1) * 0.15 + state.pointer.y * 0.08;
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#7dd3fc"
        size={0.035}
        sizeAttenuation
        depthWrite={false}
        opacity={0.85}
      />
    </Points>
  );
}

function CoreGeometry() {
  const group = useRef<Group>(null);

  useFrame((state, delta) => {
    if (!group.current) return;
    group.current.rotation.y += delta * 0.22;
    group.current.rotation.x += delta * 0.08;
    group.current.position.x = state.pointer.x * 0.5;
    group.current.position.y = state.pointer.y * 0.35;
  });

  return (
    <group ref={group}>
      <Icosahedron args={[1.9, 1]}>
        <meshBasicMaterial wireframe color="#a855f7" transparent opacity={0.55} />
      </Icosahedron>
      <Icosahedron args={[1.2, 0]}>
        <meshBasicMaterial wireframe color="#22d3ee" transparent opacity={0.45} />
      </Icosahedron>
      <Torus args={[3, 0.006, 8, 120]} rotation={[Math.PI / 2.4, 0, 0]}>
        <meshBasicMaterial color="#60a5fa" transparent opacity={0.5} />
      </Torus>
      <Torus args={[3.6, 0.005, 8, 120]} rotation={[Math.PI / 1.7, 0.6, 0]}>
        <meshBasicMaterial color="#a855f7" transparent opacity={0.4} />
      </Torus>
    </group>
  );
}

export default function Scene3D() {
  return (
    <Canvas
      camera={{ position: [0, 0, 7], fov: 55 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
      style={{ pointerEvents: "none" }}
    >
      <ParticleField />
      <CoreGeometry />
    </Canvas>
  );
}