import { useState } from "react";
import { motion } from "motion/react";
import { SectionHeading } from "./primitives";
import { TECH_ORBITS } from "@/lib/profile";

export function TechStack() {
  const [hovered, setHovered] = useState<{ name: string; note: string } | null>(null);

  return (
    <section className="section-pad relative overflow-hidden">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Tech stack"
          title="Everything orbiting the core"
          subtitle="Hover any tool to see how I use it."
        />

        <div className="relative mx-auto grid h-[560px] w-full max-w-[680px] scale-[0.6] place-items-center sm:scale-90 lg:scale-100">
          <div className="absolute h-40 w-40 rounded-full blur-[60px] [background-image:var(--gradient-neon)]" />
          <div className="glass absolute grid h-40 w-40 place-items-center rounded-full px-4 text-center">
            {hovered ? (
              <motion.span
                key={hovered.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-[11px] leading-snug text-muted-foreground"
              >
                <span className="text-gradient font-display block text-sm font-bold">
                  {hovered.name}
                </span>
                {hovered.note}
              </motion.span>
            ) : (
              <span className="text-gradient font-display text-xl font-bold">Core</span>
            )}
          </div>

          {TECH_ORBITS.map((orbit) => (
            <div
              key={orbit.radius}
              className="animate-spin-slow absolute rounded-full border border-border"
              style={{
                width: orbit.radius * 2,
                height: orbit.radius * 2,
                ["--spin-duration" as string]: `${orbit.duration}s`,
              }}
            >
              {orbit.items.map((item, i) => {
                const angle = (i / orbit.items.length) * Math.PI * 2;
                return (
                  <span
                    key={item.name}
                    className="absolute top-1/2 left-1/2"
                    style={{
                      transform: `translate(-50%,-50%) translate(${Math.cos(angle) * orbit.radius}px, ${Math.sin(angle) * orbit.radius}px)`,
                    }}
                  >
                    <button
                      type="button"
                      onMouseEnter={() => setHovered(item)}
                      onMouseLeave={() => setHovered(null)}
                      onFocus={() => setHovered(item)}
                      onBlur={() => setHovered(null)}
                      className="animate-spin-slow glass block rounded-full px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-[box-shadow,border-color,color] duration-300 hover:border-primary/60 hover:text-accent hover:shadow-[var(--shadow-neon)]"
                      style={{
                        animationDirection: "reverse",
                        ["--spin-duration" as string]: `${orbit.duration}s`,
                      }}
                    >
                      {item.name}
                    </button>
                  </span>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
