import { Download, ExternalLink, FileText } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { NAME, RESUME_HIGHLIGHTS, RESUME_URL } from "@/lib/profile";

export function Resume() {
  return (
    <section id="resume" className="section-pad relative scroll-mt-24">
      <div className="pointer-events-none absolute top-1/3 right-0 h-80 w-80 rounded-full bg-primary/10 blur-[140px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Resume"
          title="The full picture, on one page"
          subtitle="A quick summary below — open or download the full PDF for the complete version."
        />

        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <Reveal>
            <div className="glass h-full rounded-[2rem] p-8 sm:p-10">
              <div className="grid gap-8 sm:grid-cols-2">
                {RESUME_HIGHLIGHTS.map((block) => (
                  <div key={block.label}>
                    <h3 className="text-xs tracking-[0.22em] text-accent uppercase">
                      {block.label}
                    </h3>
                    <ul className="mt-4 space-y-3">
                      {block.lines.map((line) => (
                        <li
                          key={line}
                          className="flex gap-3 text-sm leading-relaxed text-muted-foreground"
                        >
                          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                          <span>{line}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.12}>
            <div className="glass flex h-full flex-col rounded-[2rem] p-8 sm:p-10">
              <span className="grid h-12 w-12 place-items-center rounded-2xl border border-primary/30 bg-primary/10 text-primary">
                <FileText className="h-5 w-5" />
              </span>
              <h3 className="mt-5 text-xl font-semibold">{NAME} — Resume</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                AI Automation Engineer · AI Chatbot &amp; LLM Developer · Python Developer.
                Computer Engineering student at UET Taxila, seeking an AI Automation /
                Chatbot Development internship.
              </p>
              <div className="mt-auto flex flex-col gap-3 pt-8">
                <a
                  href={RESUME_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-neon)] [background-image:var(--gradient-neon)]"
                >
                  <ExternalLink className="h-4 w-4" /> View Resume
                </a>
                <a
                  href={RESUME_URL}
                  download="Umbar_Gul_Naz_Resume.pdf"
                  className="glass glass-hover inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold"
                >
                  <Download className="h-4 w-4" /> Download PDF
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
