import { Reveal, SectionHeading } from "./primitives";
import {
  Bot,
  Brain,
  Code2,
  FileText,
  GraduationCap,
  Mic,
  MessagesSquare,
  Users,
  Workflow,
} from "lucide-react";
import { SOFT_SKILLS, SUMMARY } from "@/lib/profile";

const traits = [
  { icon: GraduationCap, label: "Computer Engineering Student — UET Taxila" },
  { icon: Bot, label: "AI Automation" },
  { icon: Code2, label: "Python Development" },
  { icon: MessagesSquare, label: "AI Chatbots" },
  { icon: Mic, label: "AI Voice Agents" },
  { icon: Workflow, label: "Business Automation" },
  { icon: Brain, label: "Prompt Engineering" },
  { icon: FileText, label: "Document Intelligence" },
  { icon: Users, label: "Public Speaking & Team Collaboration" },
];

export function About() {
  return (
    <section id="about" className="section-pad relative">
      <div className="pointer-events-none absolute top-1/3 left-0 h-80 w-80 rounded-full bg-primary/10 blur-[130px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="About me"
          title="Practical AI, built for real businesses"
          subtitle={SUMMARY}
        />

        <div className="grid gap-12 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="relative">
            <div className="absolute top-2 bottom-2 left-[7px] w-px opacity-60 [background-image:var(--gradient-neon)]" />
            <ul className="space-y-6">
              {traits.map((t, i) => (
                <Reveal key={t.label} delay={i * 0.06}>
                  <li className="relative flex min-w-0 items-center gap-4 pl-8">
                    <span className="absolute left-0 grid h-4 w-4 place-items-center rounded-full border border-accent/60 bg-background">
                      <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                    </span>
                    <t.icon className="h-5 w-5 shrink-0 text-accent" />
                    <span className="text-base font-medium">{t.label}</span>
                  </li>
                </Reveal>
              ))}
            </ul>
          </div>

          <div>
            <Reveal>
              <p className="text-lg leading-relaxed text-muted-foreground">
                I&apos;m a Computer Engineering student at UET Taxila working as an AI
                Automation Engineer. I build practical AI chatbots, AI voice agents and
                LLM-powered automation tools with Python — the kind of solutions a business
                can actually put in front of its customers.
              </p>
              <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
                My hands-on work covers prompt engineering, document intelligence and
                business process automation, integrating the Groq API with frameworks
                including LangChain and Streamlit. Alongside the technical side, I compete
                in British Parliamentary Debate, took part in the Young Policy Leaders
                Program, and host university events — so clear communication and teamwork
                come with the engineering.
              </p>
              <p className="mt-5 text-lg leading-relaxed text-muted-foreground">
                I&apos;m currently seeking an AI Automation / Chatbot Development
                internship where I can build real, customer-facing AI solutions.
              </p>
            </Reveal>

            <Reveal delay={0.15}>
              <ul className="mt-9 flex flex-wrap gap-2">
                {SOFT_SKILLS.map((s) => (
                  <li
                    key={s}
                    className="rounded-full border border-border bg-secondary/40 px-3.5 py-1.5 text-xs font-medium text-muted-foreground"
                  >
                    {s}
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={0.2}>
              <div className="glass mt-8 rounded-3xl p-6">
                <p className="text-xs tracking-[0.25em] text-accent uppercase">Languages</p>
                <p className="mt-3 text-base text-muted-foreground">
                  English — Fluent · Urdu — Native
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
