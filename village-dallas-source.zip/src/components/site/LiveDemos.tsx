import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Clock, Github, PlayCircle, X } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { DEMOS, GITHUB_URL, type Demo } from "@/lib/profile";

export function LiveDemos() {
  const [active, setActive] = useState<Demo | null>(null);

  return (
    <section id="demos" className="section-pad relative scroll-mt-24">
      <div className="pointer-events-none absolute top-1/3 right-0 h-96 w-96 rounded-full bg-neon-purple/12 blur-[150px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Live demos"
          title="See the systems running"
          subtitle="Recorded walkthroughs of the AI automations I have built. Nothing autoplays — press play when you're ready."
        />

        <div className="grid gap-7 md:grid-cols-2">
          {DEMOS.map((d, i) => (
            <Reveal key={d.id} delay={i * 0.1}>
              <article className="glass glass-hover group flex h-full flex-col overflow-hidden rounded-[2rem]">
                <button
                  onClick={() => setActive(d)}
                  aria-label={`Watch ${d.title} demo`}
                  className="relative block aspect-16/9 w-full overflow-hidden"
                >
                  <img
                    src={d.poster}
                    alt={`${d.title} thumbnail`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-background/45 transition-colors duration-500 group-hover:bg-background/25" />
                  <span className="glass absolute top-4 right-4 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] text-muted-foreground">
                    <Clock className="h-3 w-3" /> {d.duration}
                  </span>
                  <motion.span
                    className="absolute inset-0 grid place-items-center"
                    whileHover={{ scale: 1.06 }}
                  >
                    <span className="grid h-16 w-16 place-items-center rounded-full text-primary-foreground shadow-[var(--shadow-neon)] [background-image:var(--gradient-neon)]">
                      <PlayCircle className="h-8 w-8" />
                    </span>
                  </motion.span>
                </button>

                <div className="flex flex-1 flex-col p-7">
                  <h3 className="text-xl font-semibold">{d.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {d.description}
                  </p>
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {d.tech.map((t) => (
                      <li
                        key={t}
                        className="rounded-full border border-border bg-secondary/40 px-2.5 py-1 text-[11px] text-muted-foreground"
                      >
                        {t}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-6 flex flex-wrap gap-2 pt-1">
                    <button
                      onClick={() => setActive(d)}
                      className="inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold text-primary-foreground [background-image:var(--gradient-neon)]"
                    >
                      <PlayCircle className="h-3.5 w-3.5" /> Watch Demo
                    </button>
                    <a
                      href={GITHUB_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="glass inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold"
                    >
                      <Github className="h-3.5 w-3.5" /> GitHub
                    </a>
                    <a
                      href="#projects"
                      className="glass inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-semibold"
                    >
                      View Project
                    </a>
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-60 flex items-start justify-center overflow-y-auto bg-background/85 p-4 backdrop-blur-xl sm:p-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            role="dialog"
            aria-modal="true"
            aria-label={`${active.title} demo`}
          >
            <motion.div
              initial={{ opacity: 0, y: 44, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 24, scale: 0.97 }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="glass my-auto w-full max-w-4xl overflow-hidden rounded-[2rem]"
            >
              <div className="relative bg-black">
                <video
                  src={active.video}
                  poster={active.poster}
                  controls
                  preload="none"
                  playsInline
                  className="aspect-16/9 w-full"
                >
                  Your browser does not support embedded video.
                </video>
                <button
                  onClick={() => setActive(null)}
                  aria-label="Close demo"
                  className="glass absolute top-4 right-4 grid h-10 w-10 place-items-center rounded-full"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="p-7 sm:p-9">
                <h3 className="text-2xl font-bold sm:text-3xl">{active.title}</h3>

                <div className="mt-5 rounded-2xl border border-border bg-secondary/30 p-5">
                  <p className="text-xs font-semibold tracking-[0.2em] text-accent uppercase">
                    Problem solved
                  </p>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {active.problem}
                  </p>
                </div>

                <p className="mt-6 text-xs font-semibold tracking-[0.2em] uppercase">
                  Project overview
                </p>
                <p className="mt-2 leading-relaxed text-muted-foreground">
                  {active.overview}
                </p>

                <div className="mt-7 grid gap-7 sm:grid-cols-2">
                  <div>
                    <h4 className="text-sm font-semibold tracking-[0.2em] uppercase">
                      Technologies used
                    </h4>
                    <ul className="mt-3 flex flex-wrap gap-2">
                      {active.tech.map((t) => (
                        <li
                          key={t}
                          className="rounded-full border border-border bg-secondary/40 px-3 py-1.5 text-xs text-muted-foreground"
                        >
                          {t}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold tracking-[0.2em] uppercase">
                      Features
                    </h4>
                    <ul className="mt-3 space-y-2">
                      {active.features.map((f) => (
                        <li key={f} className="flex gap-2.5 text-sm text-muted-foreground">
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="mt-8">
                  <a
                    href={GITHUB_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground [background-image:var(--gradient-neon)]"
                  >
                    <Github className="h-4 w-4" /> GitHub Repository
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
