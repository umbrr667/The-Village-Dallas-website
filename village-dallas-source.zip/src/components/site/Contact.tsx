import { Download, Github, Linkedin, Mail, MessageCircle, Phone } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import {
  EMAIL,
  GITHUB_URL,
  LINKEDIN_URL,
  PHONE,
  RESUME_URL,
  WHATSAPP_URL,
} from "@/lib/profile";

const channels = [
  { icon: Mail, label: "Email", value: EMAIL, href: `mailto:${EMAIL}` },
  { icon: Phone, label: "Phone", value: PHONE, href: `tel:+92${PHONE.slice(1)}` },
  { icon: MessageCircle, label: "WhatsApp", value: "Message me", href: WHATSAPP_URL },
  { icon: Linkedin, label: "LinkedIn", value: "umbar-gul-naz", href: LINKEDIN_URL },
  { icon: Github, label: "GitHub", value: "umbrr667", href: GITHUB_URL },
  { icon: Download, label: "Resume", value: "Download PDF", href: RESUME_URL },
];

export function Contact() {
  return (
    <section id="contact" className="section-pad relative scroll-mt-24">
      <div className="pointer-events-none absolute inset-x-0 top-1/4 mx-auto h-96 w-[70%] rounded-full bg-primary/12 blur-[150px]" />
      <div className="relative mx-auto max-w-5xl px-5">
        <SectionHeading
          eyebrow="Contact"
          title="Let's build your AI automation"
          subtitle="Available for AI automation internships, chatbot and voice agent projects, and freelance automation work."
        />

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {channels.map((c, i) => (
            <Reveal key={c.label} delay={i * 0.06}>
              <a
                href={c.href}
                target={c.href.startsWith("http") ? "_blank" : undefined}
                rel={c.href.startsWith("http") ? "noreferrer" : undefined}
                download={c.label === "Resume" ? "Umbar_Gul_Naz_Resume.pdf" : undefined}
                className="glass glass-hover flex h-full items-center gap-4 rounded-3xl p-6"
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border border-accent/40 bg-accent/10 text-accent">
                  <c.icon className="h-5 w-5" />
                </span>
                <span className="min-w-0">
                  <span className="block text-xs tracking-[0.2em] text-muted-foreground uppercase">
                    {c.label}
                  </span>
                  <span className="mt-1 block truncate text-sm font-semibold">
                    {c.value}
                  </span>
                </span>
              </a>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2}>
          <div className="glass mt-10 rounded-[2rem] p-8 text-center sm:p-12">
            <h3 className="text-2xl font-bold sm:text-3xl">
              <span className="text-gradient">Have a process worth automating?</span>
            </h3>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground">
              Tell me the task that eats your team&apos;s time — support replies, document
              review, repetitive workflows — and I&apos;ll tell you how AI can handle it.
            </p>
            <a
              href={`mailto:${EMAIL}`}
              className="mt-8 inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-neon)] [background-image:var(--gradient-neon)]"
            >
              <Mail className="h-4 w-4" /> Email me
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
