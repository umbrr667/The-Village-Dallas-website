import { motion } from "motion/react";
import { Reveal, SectionHeading } from "./primitives";
import { WORKFLOW_STEPS } from "@/lib/profile";

export function WorkflowTimeline() {
  return (
    <section className="section-pad relative overflow-hidden">
      <div className="relative mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="How I work"
          title="Development workflow"
          subtitle="From understanding the business process to supporting the shipped automation."
        />

        <div className="relative">
          <motion.div
            aria-hidden
            className="absolute top-6 right-0 left-0 hidden h-px origin-left [background-image:var(--gradient-neon)] lg:block"
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
          />

          <ol className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {WORKFLOW_STEPS.map((s, i) => (
              <Reveal key={s.title} delay={i * 0.08}>
                <li className="relative">
                  <span className="relative z-10 grid h-12 w-12 place-items-center rounded-full border border-primary/40 bg-background font-display text-sm font-bold text-accent shadow-[var(--shadow-neon)]">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="glass glass-hover mt-5 h-[calc(100%-4.25rem)] rounded-3xl p-6">
                    <h3 className="text-base font-semibold">{s.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                      {s.desc}
                    </p>
                  </div>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
