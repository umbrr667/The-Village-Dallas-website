import { useState, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ChevronLeft, ChevronRight, Expand } from "lucide-react";
import { Reveal, SectionHeading } from "./primitives";
import { GALLERY } from "@/lib/village";

export function VillageGallery() {
  const [index, setIndex] = useState<number | null>(null);

  const close = useCallback(() => setIndex(null), []);
  const step = useCallback(
    (dir: number) => setIndex((i) => (i === null ? i : (i + dir + GALLERY.length) % GALLERY.length)),
    [],
  );

  useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, close, step]);

  const active = index === null ? null : GALLERY[index];

  return (
    <section id="gallery" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Gallery"
          title="Moments at The Village"
          subtitle="Golden hour on the rooftop, the hush of the spa, the glow of the bar after ten."
        />

        <div className="grid auto-rows-[220px] grid-cols-2 gap-4 lg:grid-cols-4">
          {GALLERY.map((g, i) => (
            <Reveal key={g.alt} delay={(i % 4) * 0.07} className={`${g.span} h-full`}>
              <motion.button
                onClick={() => setIndex(i)}
                whileHover={{ scale: 1.015 }}
                transition={{ type: "spring", stiffness: 240, damping: 22 }}
                className="group relative h-full w-full overflow-hidden rounded-[1.5rem] border border-white/10"
                aria-label={`Open image: ${g.alt}`}
              >
                <img
                  src={g.src}
                  alt={g.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-115"
                />
                <span className="absolute inset-0 bg-[oklch(0.11_0.004_60/45%)] opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                <span className="absolute inset-0 grid place-items-center opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                  <span className="lux-glass grid h-11 w-11 place-items-center rounded-full text-[var(--gold)]">
                    <Expand className="h-4 w-4" />
                  </span>
                </span>
              </motion.button>
            </Reveal>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {active ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] grid place-items-center bg-[oklch(0.06_0.003_60/92%)] p-4 backdrop-blur-xl"
            onClick={close}
            role="dialog"
            aria-modal="true"
            aria-label="Image viewer"
          >
            <motion.img
              key={active.src}
              src={active.src}
              alt={active.alt}
              initial={{ scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.96, opacity: 0 }}
              transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="max-h-[82vh] w-auto max-w-full rounded-[1.5rem] border border-white/10 object-contain"
            />
            <p className="mt-5 text-[0.66rem] tracking-[0.26em] text-white/50 uppercase">
              {active.alt}
            </p>

            <button
              onClick={close}
              aria-label="Close viewer"
              className="lux-glass absolute top-6 right-6 grid h-11 w-11 place-items-center rounded-full"
            >
              <X className="h-4 w-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                step(-1);
              }}
              aria-label="Previous image"
              className="lux-glass absolute top-1/2 left-4 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full sm:left-8"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                step(1);
              }}
              aria-label="Next image"
              className="lux-glass absolute top-1/2 right-4 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full sm:right-8"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </section>
  );
}
