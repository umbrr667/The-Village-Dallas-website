import { motion, useInView, useMotionValue, useSpring } from "motion/react";
import { useRef, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Reveal({
  children,
  delay = 0,
  y = 34,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y, filter: "blur(10px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "-90px" }}
      transition={{ duration: 1, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  className,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
  className?: string;
}) {
  return (
    <Reveal
      className={cn(
        "mb-14 max-w-2xl",
        align === "center" ? "mx-auto text-center" : "text-left",
        className,
      )}
    >
      <span className="text-[0.68rem] tracking-[0.42em] text-[var(--gold)] uppercase">
        {eyebrow}
      </span>
      <div
        className={cn("gold-rule mt-4 w-24", align === "center" && "mx-auto")}
        aria-hidden
      />
      <h2 className="font-serif-lux mt-5 text-4xl leading-[1.05] font-light text-balance sm:text-5xl md:text-6xl">
        {title}
      </h2>
      {subtitle ? (
        <p className="mt-5 text-sm leading-relaxed font-light text-white/60 sm:text-base">
          {subtitle}
        </p>
      ) : null}
    </Reveal>
  );
}

export function MagneticButton({
  children,
  href,
  onClick,
  variant = "gold",
  className,
  type,
}: {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "gold" | "outline";
  className?: string;
  type?: "button" | "submit";
}) {
  const ref = useRef<HTMLElement>(null);
  const x = useSpring(useMotionValue(0), { stiffness: 210, damping: 17 });
  const y = useSpring(useMotionValue(0), { stiffness: 210, damping: 17 });

  function handleMove(e: React.MouseEvent) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    x.set((e.clientX - (r.left + r.width / 2)) * 0.3);
    y.set((e.clientY - (r.top + r.height / 2)) * 0.4);
  }

  const base =
    "group relative inline-flex items-center justify-center gap-2.5 overflow-hidden rounded-full px-8 py-3.5 text-[0.72rem] font-medium tracking-[0.24em] uppercase transition-colors duration-500";
  const styles =
    variant === "gold"
      ? "text-[oklch(0.14_0.01_70)] [background-image:linear-gradient(100deg,oklch(0.92_0.07_92),oklch(0.82_0.12_85)_50%,oklch(0.72_0.11_75))] shadow-[0_18px_50px_-22px_oklch(0.82_0.12_85/70%)]"
      : "lux-glass text-white/85 hover:text-white hover:border-[oklch(0.82_0.12_85/45%)]";

  const Comp = (href ? motion.a : motion.button) as typeof motion.a;

  return (
    <Comp
      ref={ref as never}
      href={href}
      type={href ? undefined : (type ?? "button")}
      onClick={onClick}
      onMouseMove={handleMove}
      onMouseLeave={() => {
        x.set(0);
        y.set(0);
      }}
      style={{ x, y }}
      whileTap={{ scale: 0.96 }}
      className={cn(base, styles, className)}
    >
      <span className="relative z-10 inline-flex items-center gap-2.5">{children}</span>
      <span
        aria-hidden
        className="absolute inset-0 -translate-x-full bg-[linear-gradient(100deg,transparent,oklch(1_0_0/28%),transparent)] transition-transform duration-[900ms] group-hover:translate-x-full"
      />
    </Comp>
  );
}

export function GlassCard({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      transition={{ type: "spring", stiffness: 240, damping: 22 }}
      className={cn(
        "lux-glass group relative overflow-hidden rounded-[1.75rem] transition-colors duration-500 hover:border-[oklch(0.82_0.12_85/40%)]",
        className,
      )}
    >
      {children}
    </motion.div>
  );
}

export function ImageReveal({
  src,
  alt,
  className,
  imgClassName,
}: {
  src: string;
  alt: string;
  className?: string;
  imgClassName?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-70px" });

  return (
    <div ref={ref} className={cn("relative overflow-hidden", className)}>
      <motion.img
        src={src}
        alt={alt}
        loading="lazy"
        initial={{ scale: 1.18, opacity: 0 }}
        animate={inView ? { scale: 1, opacity: 1 } : {}}
        transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
        className={cn("h-full w-full object-cover", imgClassName)}
      />
      <motion.span
        aria-hidden
        initial={{ scaleX: 1 }}
        animate={inView ? { scaleX: 0 } : {}}
        transition={{ duration: 1.1, ease: [0.76, 0, 0.24, 1] }}
        style={{ transformOrigin: "right" }}
        className="absolute inset-0 bg-[var(--ink)]"
      />
    </div>
  );
}
