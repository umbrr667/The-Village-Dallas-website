import { motion } from "motion/react";
import { Reveal, SectionHeading, ImageReveal } from "./primitives";
import { AMENITIES } from "@/lib/village";

export function VillageAmenities() {
  return (
    <section id="amenities" className="relative px-5 py-28 sm:py-36">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-1/3 -z-10 h-[40vh] bg-[radial-gradient(ellipse_at_center,oklch(0.82_0.12_85/9%),transparent_70%)]"
      />
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Amenities"
          title="Everything, within a few steps"
          subtitle="Wellness, water and warmth — designed as a single continuous experience rather than a list of facilities."
        />

        <div className="grid gap-7 lg:grid-cols-3">
          {AMENITIES.map((a, i) => (
            <Reveal key={a.title} delay={i * 0.12}>
              <motion.div
                whileHover={{ y: -10 }}
                transition={{ type: "spring", stiffness: 220, damping: 20 }}
                className="lux-glass group relative h-full overflow-hidden rounded-[1.75rem] transition-colors duration-500 hover:border-[oklch(0.82_0.12_85/40%)]"
              >
                <ImageReveal
                  src={a.image}
                  alt={a.title}
                  className="aspect-[5/6]"
                  imgClassName="transition-transform duration-[1300ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_35%,oklch(0.11_0.004_60/92%))]" />
                <div className="absolute inset-x-0 bottom-0 p-7">
                  <h3 className="font-serif-lux text-2xl font-light">{a.title}</h3>
                  <p className="mt-2 max-h-0 overflow-hidden text-sm leading-relaxed font-light text-white/65 opacity-0 transition-all duration-700 group-hover:max-h-32 group-hover:opacity-100">
                    {a.copy}
                  </p>
                  <div className="gold-rule mt-4 w-0 transition-all duration-700 group-hover:w-24" />
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
