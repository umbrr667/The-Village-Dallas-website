import { lazy, Suspense } from "react";
import { ClientOnly } from "@tanstack/react-router";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowDown, CalendarCheck } from "lucide-react";
import { MagneticButton } from "./primitives";
import heroNight from "@/assets/village/hero-night.jpg";

const HotelScene = lazy(() => import("./HotelScene"));

const WORDS = "Experience Luxury Living at The Village Dallas".split(" ");

export function VillageHero() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 800], [0, 160]);
  const bgY = useTransform(scrollY, [0, 800], [0, 90]);
  const opacity = useTransform(scrollY, [0, 560], [1, 0]);

  return (
    <section id="top" className="relative flex min-h-screen items-center overflow-hidden">
      <motion.div style={{ y: bgY }} className="absolute inset-0 z-0">
        <img
          src={heroNight}
          alt="The Village Dallas illuminated at dusk"
          className="h-[115%] w-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,oklch(0.11_0.004_60/70%),oklch(0.11_0.004_60/38%)_45%,oklch(0.11_0.004_60))]" />
      </motion.div>

      <div className="pointer-events-none absolute inset-0">
        <motion.div
          className="absolute top-[-18%] left-1/2 h-[62vh] w-[64vw] -translate-x-1/2 rounded-full bg-[oklch(0.82_0.12_85/12%)] blur-[160px]"
          animate={{ opacity: [0.5, 1, 0.5], scale: [1, 1.1, 1] }}
          transition={{ duration: 13, repeat: Infinity, ease: "easeInOut" }}
        />
        {Array.from({ length: 16 }, (_, i) => (
          <motion.span
            key={i}
            className="absolute rounded-full bg-[var(--gold)]/50"
            style={{
              left: `${(i * 17.3) % 96}%`,
              top: `${(i * 31.7) % 92}%`,
              width: 2 + (i % 3),
              height: 2 + (i % 3),
            }}
            animate={{ y: [0, -30, 0], opacity: [0.1, 0.7, 0.1] }}
            transition={{
              duration: 7 + (i % 5) * 1.7,
              delay: (i % 8) * 0.6,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      <div className="absolute inset-0 opacity-60">
        <ClientOnly fallback={null}>
          <Suspense fallback={null}>
            <HotelScene />
          </Suspense>
        </ClientOnly>
      </div>

      <motion.div
        style={{ y, opacity }}
        className="relative z-10 mx-auto w-full max-w-4xl px-5 pt-32 pb-28 text-center"
      >
        <motion.span
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 1 }}
          className="text-[0.66rem] tracking-[0.5em] text-[var(--gold)] uppercase"
        >
          Dallas · Texas
        </motion.span>

        <h1 className="font-serif-lux mt-7 text-5xl leading-[1.02] font-light text-balance sm:text-6xl lg:text-7xl">
          {WORDS.map((w, i) => (
            <motion.span
              key={`${w}-${i}`}
              initial={{ opacity: 0, y: 40, filter: "blur(12px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ delay: 0.75 + i * 0.09, duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="inline-block whitespace-pre"
            >
              <span className={i > 3 ? "gold-text" : ""}>{w}</span>{" "}
            </motion.span>
          ))}
        </h1>

        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 1.5, duration: 1.2 }}
          className="gold-rule mx-auto mt-8 w-40"
        />

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.7, duration: 1 }}
          className="mx-auto mt-7 max-w-xl text-sm leading-relaxed font-light text-white/65 sm:text-base"
        >
          A residential resort in the heart of Dallas — rooftop pools, hearth-fired dining,
          a spa carved from marble, and 24-hour attentiveness that never feels like service.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.9, duration: 1 }}
          className="mt-11 flex flex-wrap justify-center gap-3"
        >
          <MagneticButton href="#booking">
            <CalendarCheck className="h-3.5 w-3.5" /> Book Your Stay
          </MagneticButton>
          <MagneticButton href="#rooms" variant="outline">
            Explore Rooms <ArrowDown className="h-3.5 w-3.5" />
          </MagneticButton>
        </motion.div>
      </motion.div>

      <div className="absolute inset-x-0 bottom-8 flex justify-center">
        <motion.a
          href="#about"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2.4, repeat: Infinity }}
          className="text-[0.6rem] tracking-[0.42em] text-white/40 uppercase"
        >
          Scroll
        </motion.a>
      </div>
    </section>
  );
}
