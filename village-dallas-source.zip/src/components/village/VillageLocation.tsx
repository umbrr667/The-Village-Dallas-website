import { motion } from "motion/react";
import { MapPin, Phone, Mail, Navigation } from "lucide-react";
import { Reveal, SectionHeading, MagneticButton } from "./primitives";
import { HOTEL } from "@/lib/village";

const POINTS = [
  { label: "Katy Trail", d: "2 min walk", x: "24%", y: "38%" },
  { label: "Greenville Ave", d: "5 min walk", x: "68%", y: "28%" },
  { label: "Arts District", d: "12 min drive", x: "44%", y: "68%" },
  { label: "DFW Airport", d: "26 min drive", x: "80%", y: "72%" },
];

export function VillageLocation() {
  return (
    <section id="location" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Location"
          title="Between the trail and the city"
          subtitle="Twelve acres off Greenville Avenue — quiet enough to sleep, close enough to everything."
        />

        <div className="grid gap-8 lg:grid-cols-[1.25fr_0.75fr]">
          <Reveal>
            <div className="lux-glass relative aspect-[16/11] overflow-hidden rounded-[2rem]">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_35%_40%,oklch(0.82_0.12_85/12%),transparent_60%),linear-gradient(160deg,oklch(0.16_0.006_60),oklch(0.11_0.004_60))]" />
              <svg
                aria-hidden
                viewBox="0 0 100 70"
                preserveAspectRatio="none"
                className="absolute inset-0 h-full w-full opacity-40"
              >
                {[12, 26, 40, 54, 68].map((y) => (
                  <line
                    key={`h${y}`}
                    x1="0"
                    y1={y}
                    x2="100"
                    y2={y}
                    stroke="oklch(1 0 0 / 12%)"
                    strokeWidth="0.2"
                  />
                ))}
                {[14, 32, 50, 68, 86].map((x) => (
                  <line
                    key={`v${x}`}
                    x1={x}
                    y1="0"
                    x2={x}
                    y2="70"
                    stroke="oklch(1 0 0 / 12%)"
                    strokeWidth="0.2"
                  />
                ))}
                <path
                  d="M0 52 C 22 46, 34 30, 52 26 S 84 16, 100 8"
                  fill="none"
                  stroke="oklch(0.82 0.12 85 / 45%)"
                  strokeWidth="0.5"
                  strokeDasharray="2 1.4"
                />
              </svg>

              {POINTS.map((p, i) => (
                <motion.div
                  key={p.label}
                  initial={{ opacity: 0, scale: 0.6 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + i * 0.14, duration: 0.7 }}
                  className="group absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: p.x, top: p.y }}
                >
                  <span className="relative grid h-3 w-3 place-items-center">
                    <span className="absolute h-3 w-3 animate-ping rounded-full bg-[var(--gold)]/40" />
                    <span className="h-2 w-2 rounded-full bg-[var(--gold)]" />
                  </span>
                  <span className="lux-glass absolute top-5 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-[0.58rem] tracking-[0.16em] whitespace-nowrap text-white/70 uppercase opacity-0 transition-opacity duration-500 group-hover:opacity-100">
                    {p.label} · {p.d}
                  </span>
                </motion.div>
              ))}

              <div className="lux-glass absolute bottom-5 left-5 rounded-2xl px-5 py-4">
                <p className="font-serif-lux text-lg">{HOTEL.name}</p>
                <p className="mt-1 text-[0.62rem] tracking-[0.18em] text-white/50 uppercase">
                  {HOTEL.address}
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.12}>
            <div className="lux-glass flex h-full flex-col justify-between rounded-[2rem] p-8">
              <div className="space-y-6">
                {[
                  { icon: MapPin, label: "Address", value: HOTEL.address },
                  { icon: Phone, label: "Reservations", value: HOTEL.phone },
                  { icon: Mail, label: "Email", value: HOTEL.email },
                ].map((row) => (
                  <div key={row.label} className="flex gap-4">
                    <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[oklch(0.82_0.12_85/30%)] text-[var(--gold)]">
                      <row.icon className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-[0.6rem] tracking-[0.28em] text-white/40 uppercase">
                        {row.label}
                      </p>
                      <p className="mt-1 text-sm font-light text-white/75">{row.value}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-10">
                <MagneticButton href={HOTEL.mapUrl} variant="outline" className="w-full">
                  <Navigation className="h-3.5 w-3.5" /> Get Directions
                </MagneticButton>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
