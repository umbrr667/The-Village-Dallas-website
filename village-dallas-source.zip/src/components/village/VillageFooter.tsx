import { motion } from "motion/react";
import { HOTEL, NAV } from "@/lib/village";

export function VillageFooter() {
  return (
    <footer className="relative border-t border-white/[0.08] px-5 pt-20 pb-10">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_1fr_1fr]">
          <div>
            <p className="font-serif-lux text-3xl font-light gold-text">{HOTEL.name}</p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed font-light text-white/50">
              A residential resort in the heart of Dallas — twelve acres of gardens, water and
              quiet luxury.
            </p>
          </div>

          <nav aria-label="Footer">
            <p className="text-[0.6rem] tracking-[0.32em] text-white/35 uppercase">Explore</p>
            <ul className="mt-5 grid grid-cols-2 gap-y-3">
              {NAV.map((n) => (
                <li key={n.href}>
                  <motion.a
                    href={n.href}
                    whileHover={{ x: 5 }}
                    className="inline-block text-sm font-light text-white/55 transition-colors hover:text-[var(--gold)]"
                  >
                    {n.label}
                  </motion.a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="text-[0.6rem] tracking-[0.32em] text-white/35 uppercase">Contact</p>
            <ul className="mt-5 space-y-3 text-sm font-light text-white/55">
              <li>{HOTEL.address}</li>
              <li>
                <a href={`tel:${HOTEL.phone.replace(/[^+\d]/g, "")}`} className="hover:text-[var(--gold)]">
                  {HOTEL.phone}
                </a>
              </li>
              <li>
                <a href={`mailto:${HOTEL.email}`} className="hover:text-[var(--gold)]">
                  {HOTEL.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="gold-rule mt-14" />
        <div className="mt-7 flex flex-col gap-3 text-[0.62rem] tracking-[0.2em] text-white/30 uppercase sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} {HOTEL.name}. Concept redesign.</p>
          <p>Designed with React, Three.js & Motion</p>
        </div>
      </div>
    </footer>
  );
}
