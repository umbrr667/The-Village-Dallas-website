import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Phone } from "lucide-react";
import { HOTEL, NAV } from "@/lib/village";

export function VillageNav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -70, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="fixed inset-x-0 top-0 z-50 px-4 pt-4"
    >
      <nav
        className={`mx-auto flex max-w-7xl items-center justify-between rounded-full px-5 py-3 transition-all duration-700 ${
          scrolled ? "lux-glass" : "border border-transparent"
        }`}
      >
        <a href="#top" className="flex min-w-0 items-center gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-[oklch(0.82_0.12_85/45%)] text-[0.7rem] tracking-[0.1em] text-[var(--gold)]">
            VD
          </span>
          <span className="font-serif-lux truncate text-base tracking-wide">
            The Village <span className="gold-text">Dallas</span>
          </span>
        </a>

        <div className="hidden items-center gap-1 lg:flex">
          {NAV.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="relative rounded-full px-3.5 py-2 text-[0.7rem] tracking-[0.18em] text-white/60 uppercase transition-colors hover:text-white"
            >
              {l.label}
            </a>
          ))}
          <a
            href={`tel:${HOTEL.phone.replace(/[^+\d]/g, "")}`}
            className="ml-2 inline-flex items-center gap-2 text-[0.7rem] tracking-[0.18em] text-white/60 uppercase transition-colors hover:text-[var(--gold)]"
          >
            <Phone className="h-3.5 w-3.5" />
          </a>
          <a
            href="#booking"
            className="ml-3 rounded-full px-6 py-2.5 text-[0.68rem] font-medium tracking-[0.22em] text-[oklch(0.14_0.01_70)] uppercase [background-image:linear-gradient(100deg,oklch(0.92_0.07_92),oklch(0.82_0.12_85)_55%,oklch(0.72_0.11_75))]"
          >
            Book
          </a>
        </div>

        <button
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
          className="lux-glass grid h-10 w-10 shrink-0 place-items-center rounded-full lg:hidden"
        >
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -14 }}
            className="lux-glass mx-auto mt-2 max-w-7xl overflow-hidden rounded-[1.75rem] p-3 lg:hidden"
          >
            {NAV.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="block rounded-2xl px-4 py-3 text-[0.72rem] tracking-[0.2em] text-white/70 uppercase hover:bg-white/5 hover:text-white"
              >
                {l.label}
              </a>
            ))}
            <a
              href="#booking"
              onClick={() => setOpen(false)}
              className="mt-2 block rounded-2xl px-4 py-3 text-center text-[0.7rem] font-medium tracking-[0.22em] text-[oklch(0.14_0.01_70)] uppercase [background-image:linear-gradient(100deg,oklch(0.92_0.07_92),oklch(0.82_0.12_85)_55%,oklch(0.72_0.11_75))]"
            >
              Book Your Stay
            </a>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
