import { useEffect, useState } from "react";
import { motion } from "motion/react";

export function VillageCursor() {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [active, setActive] = useState(false);

  useEffect(() => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    const move = (e: MouseEvent) => {
      setPos({ x: e.clientX, y: e.clientY });
      const t = e.target as HTMLElement | null;
      setActive(Boolean(t?.closest("a,button,[role='button']")));
    };
    window.addEventListener("mousemove", move, { passive: true });
    return () => window.removeEventListener("mousemove", move);
  }, []);

  return (
    <motion.div
      aria-hidden
      className="pointer-events-none fixed top-0 left-0 z-[70] hidden rounded-full border border-[oklch(0.82_0.12_85/55%)] lg:block"
      animate={{
        x: pos.x - (active ? 26 : 14),
        y: pos.y - (active ? 26 : 14),
        width: active ? 52 : 28,
        height: active ? 52 : 28,
        opacity: active ? 1 : 0.55,
      }}
      transition={{ type: "spring", stiffness: 350, damping: 26, mass: 0.4 }}
    />
  );
}
