import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Quote, ChevronLeft, ChevronRight, Star } from "lucide-react";
import { SectionHeading } from "./primitives";
import { REVIEWS } from "@/lib/village";

export function VillageReviews() {
  const [i, setI] = useState(0);
  const r = REVIEWS[i]!;

  return (
    <section id="reviews" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-4xl text-center">
        <SectionHeading
          eyebrow="Guest Reviews"
          title="In their words"
        />

        <div className="lux-glass relative overflow-hidden rounded-[2rem] px-7 py-14 sm:px-16">
          <Quote
            aria-hidden
            className="mx-auto mb-8 h-8 w-8 text-[var(--gold)] opacity-70"
          />
          <AnimatePresence mode="wait">
            <motion.blockquote
              key={i}
              initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -20, filter: "blur(8px)" }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            >
              <p className="font-serif-lux text-2xl leading-relaxed font-light text-balance sm:text-3xl">
                “{r.quote}”
              </p>
              <footer className="mt-8">
                <div className="flex justify-center gap-1" aria-label="Five star rating">
                  {Array.from({ length: 5 }, (_, s) => (
                    <Star key={s} className="h-3.5 w-3.5 fill-[var(--gold)] text-[var(--gold)]" />
                  ))}
                </div>
                <p className="mt-4 text-sm tracking-[0.18em] text-white/80 uppercase">{r.name}</p>
                <p className="mt-1 text-[0.66rem] tracking-[0.24em] text-white/40 uppercase">
                  {r.role}
                </p>
              </footer>
            </motion.blockquote>
          </AnimatePresence>

          <div className="mt-10 flex items-center justify-center gap-4">
            <button
              onClick={() => setI((v) => (v - 1 + REVIEWS.length) % REVIEWS.length)}
              aria-label="Previous review"
              className="lux-glass grid h-10 w-10 place-items-center rounded-full transition-colors hover:border-[oklch(0.82_0.12_85/45%)]"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <div className="flex gap-2">
              {REVIEWS.map((_, d) => (
                <button
                  key={d}
                  onClick={() => setI(d)}
                  aria-label={`Go to review ${d + 1}`}
                  className={`h-1.5 rounded-full transition-all duration-500 ${
                    d === i ? "w-8 bg-[var(--gold)]" : "w-1.5 bg-white/25"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => setI((v) => (v + 1) % REVIEWS.length)}
              aria-label="Next review"
              className="lux-glass grid h-10 w-10 place-items-center rounded-full transition-colors hover:border-[oklch(0.82_0.12_85/45%)]"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
