import { motion } from "motion/react";
import { Clock } from "lucide-react";
import { Reveal, SectionHeading, ImageReveal, MagneticButton } from "./primitives";
import { DINING } from "@/lib/village";

export function VillageDining() {
  return (
    <section id="dining" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Dining"
          title="Fire, Cellar & Late Nights"
          subtitle="Two rooms with distinct personalities, one kitchen philosophy: local produce, uncomplicated technique, generous hospitality."
        />

        <div className="space-y-20">
          {DINING.map((d, i) => (
            <div
              key={d.name}
              className={`grid items-center gap-10 lg:grid-cols-2 ${
                i % 2 === 1 ? "lg:[&>*:first-child]:order-2" : ""
              }`}
            >
              <Reveal>
                <ImageReveal
                  src={d.image}
                  alt={`${d.name} at The Village Dallas`}
                  className="aspect-[4/3] rounded-[2rem]"
                  imgClassName="transition-transform duration-[1300ms] hover:scale-105"
                />
              </Reveal>
              <Reveal delay={0.1}>
                <span className="text-[0.62rem] tracking-[0.34em] text-[var(--gold)] uppercase">
                  {d.kind}
                </span>
                <h3 className="font-serif-lux mt-4 text-4xl font-light sm:text-5xl">{d.name}</h3>
                <div className="gold-rule mt-5 w-24" />
                <p className="mt-5 max-w-md text-sm leading-relaxed font-light text-white/60 sm:text-base">
                  {d.copy}
                </p>
                <p className="mt-5 inline-flex items-center gap-2 text-[0.66rem] tracking-[0.22em] text-white/45 uppercase">
                  <Clock className="h-3.5 w-3.5 text-[var(--gold)]" /> {d.hours}
                </p>
                <motion.div className="mt-8">
                  <MagneticButton href="#contact" variant="outline">
                    Reserve a Table
                  </MagneticButton>
                </motion.div>
              </Reveal>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
