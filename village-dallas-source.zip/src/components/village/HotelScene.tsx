import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Float, RoundedBox, Points, PointMaterial } from "@react-three/drei";
import { useMemo, useRef } from "react";
import type { Group, Points as ThreePoints } from "three";

function Dust() {
  const ref = useRef<ThreePoints>(null);
  const positions = useMemo(() => {
    const arr = new Float32Array(1200 * 3);
    for (let i = 0; i < arr.length; i += 3) {
      arr[i] = (Math.random() - 0.5) * 18;
      arr[i + 1] = (Math.random() - 0.5) * 12;
      arr[i + 2] = (Math.random() - 0.5) * 12;
    }
    return arr;
  }, []);

  useFrame((state, delta) => {
    if (!ref.current) return;
    ref.current.rotation.y += delta * 0.02;
    ref.current.position.y = Math.sin(state.clock.elapsedTime * 0.15) * 0.3;
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#e6c88a"
        size={0.035}
        sizeAttenuation
        depthWrite={false}
        opacity={0.7}
      />
    </Points>
  );
}

function Tower() {
  const group = useRef<Group>(null);

  useFrame((state, delta) => {
    if (!group.current) return;
    group.current.rotation.y += delta * 0.09;
    group.current.rotation.x = state.pointer.y * 0.12;
    group.current.position.x = state.pointer.x * 0.35;
  });

  const floors = useMemo(() => Array.from({ length: 9 }, (_, i) => i), []);

  return (
    <group ref={group} position={[0, -0.6, 0]}>
      {floors.map((i) => {
        const w = 2.5 - i * 0.14;
        return (
          <RoundedBox
            key={i}
            args={[w, 0.34, w]}
            radius={0.05}
            smoothness={3}
            position={[0, i * 0.52 - 1.4, 0]}
            rotation={[0, i * 0.075, 0]}
          >
            <meshStandardMaterial
              color={i % 2 === 0 ? "#1a1a1a" : "#2a2520"}
              metalness={0.9}
              roughness={0.22}
              emissive="#c9a227"
              emissiveIntensity={i % 2 === 0 ? 0.06 : 0.16}
            />
          </RoundedBox>
        );
      })}
      <mesh position={[0, -1.78, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[2.5, 3.6, 96]} />
        <meshBasicMaterial color="#c9a227" transparent opacity={0.18} />
      </mesh>
      <mesh position={[0, 3.5, 0]}>
        <sphereGeometry args={[0.14, 24, 24]} />
        <meshBasicMaterial color="#f0dca8" />
      </mesh>
      <pointLight position={[0, 3.5, 0]} intensity={9} color="#f0d18a" distance={12} />
    </group>
  );
}

export default function HotelScene() {
  return (
    <Canvas
      camera={{ position: [0, 1.4, 10.5], fov: 40 }}
      dpr={[1, 1.7]}
      gl={{ antialias: true, alpha: true }}
      style={{ pointerEvents: "none" }}
    >
      <ambientLight intensity={0.35} />
      <spotLight position={[6, 8, 6]} angle={0.5} intensity={40} color="#ffe6b0" penumbra={1} />
      <spotLight position={[-7, 3, -4]} angle={0.7} intensity={22} color="#8fb4ff" penumbra={1} />
      <group scale={0.48} position={[0, 2.1, 0]}>
        <Float speed={1.1} rotationIntensity={0.2} floatIntensity={0.7}>
          <Tower />
        </Float>
      </group>
      <Dust />
      <Environment preset="night" />
    </Canvas>
  );
}
