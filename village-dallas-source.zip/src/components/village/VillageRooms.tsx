import { motion } from "motion/react";
import { ArrowUpRight, Maximize2, Users } from "lucide-react";
import { Reveal, SectionHeading, MagneticButton } from "./primitives";
import { ROOMS } from "@/lib/village";

export function VillageRooms() {
  return (
    <section id="rooms" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Accommodation"
          title="Rooms & Residences"
          subtitle="Three signature layouts, each finished with natural stone, tailored linens and light that changes beautifully through the day."
        />

        <div className="grid gap-7 md:grid-cols-2 lg:grid-cols-3">
          {ROOMS.map((room, i) => (
            <Reveal key={room.id} delay={i * 0.1}>
              <motion.article
                whileHover={{ y: -10 }}
                transition={{ type: "spring", stiffness: 220, damping: 20 }}
                className="lux-glass group flex h-full flex-col overflow-hidden rounded-[1.75rem] transition-colors duration-500 hover:border-[oklch(0.82_0.12_85/40%)] hover:shadow-[0_40px_90px_-45px_oklch(0.82_0.12_85/45%)]"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={room.image}
                    alt={`${room.name} at The Village Dallas`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_40%,oklch(0.11_0.004_60/85%))]" />
                  <span className="lux-glass absolute top-4 left-4 rounded-full px-3.5 py-1.5 text-[0.6rem] tracking-[0.24em] text-[var(--gold)] uppercase">
                    From ${room.price} / night
                  </span>
                </div>

                <div className="flex flex-1 flex-col p-6">
                  <h3 className="font-serif-lux text-2xl font-light">{room.name}</h3>
                  <div className="mt-3 flex flex-wrap gap-4 text-[0.62rem] tracking-[0.2em] text-white/45 uppercase">
                    <span className="inline-flex items-center gap-1.5">
                      <Maximize2 className="h-3 w-3 text-[var(--gold)]" /> {room.size}
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="h-3 w-3 text-[var(--gold)]" /> {room.guests}
                    </span>
                  </div>
                  <p className="mt-4 text-sm leading-relaxed font-light text-white/60">
                    {room.blurb}
                  </p>

                  <ul className="mt-5 flex flex-wrap gap-2">
                    {room.features.map((f) => (
                      <li
                        key={f}
                        className="rounded-full border border-white/10 px-3 py-1 text-[0.62rem] tracking-[0.12em] text-white/55"
                      >
                        {f}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-7 flex-1" />
                  <MagneticButton href="#booking" variant="outline" className="w-full">
                    Book Now <ArrowUpRight className="h-3.5 w-3.5" />
                  </MagneticButton>
                </div>
              </motion.article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
