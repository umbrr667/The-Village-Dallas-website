import { useState } from "react";
import { motion } from "motion/react";
import { Send, Phone, Mail, MapPin } from "lucide-react";
import { Reveal, SectionHeading, MagneticButton } from "./primitives";
import { HOTEL } from "@/lib/village";

const field =
  "w-full rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3.5 text-sm font-light text-white/85 outline-none transition-colors placeholder:text-white/30 focus:border-[oklch(0.82_0.12_85/55%)]";

export function VillageContact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Contact"
          title="Speak with the house"
          subtitle="Our reservations team replies within a few hours, every day of the year."
        />

        <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr]">
          <Reveal>
            <div className="lux-glass h-full rounded-[2rem] p-8">
              <p className="font-serif-lux text-2xl font-light">{HOTEL.name}</p>
              <div className="gold-rule mt-5 w-20" />
              <div className="mt-8 space-y-6">
                {[
                  { icon: Phone, label: "Call", value: HOTEL.phone, href: `tel:${HOTEL.phone.replace(/[^+\d]/g, "")}` },
                  { icon: Mail, label: "Email", value: HOTEL.email, href: `mailto:${HOTEL.email}` },
                  { icon: MapPin, label: "Visit", value: HOTEL.address, href: HOTEL.mapUrl },
                ].map((c) => (
                  <motion.a
                    key={c.label}
                    href={c.href}
                    whileHover={{ x: 6 }}
                    className="flex gap-4"
                  >
                    <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full border border-[oklch(0.82_0.12_85/30%)] text-[var(--gold)]">
                      <c.icon className="h-4 w-4" />
                    </span>
                    <span>
                      <span className="block text-[0.6rem] tracking-[0.28em] text-white/40 uppercase">
                        {c.label}
                      </span>
                      <span className="mt-1 block text-sm font-light text-white/75">{c.value}</span>
                    </span>
                  </motion.a>
                ))}
              </div>
              <p className="mt-10 text-[0.62rem] leading-relaxed tracking-[0.14em] text-white/30 uppercase">
                {HOTEL.note}
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.12}>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSent(true);
              }}
              className="lux-glass rounded-[2rem] p-8"
            >
              <div className="grid gap-5 sm:grid-cols-2">
                <input required placeholder="Full name" aria-label="Full name" className={field} />
                <input
                  required
                  type="email"
                  placeholder="Email address"
                  aria-label="Email address"
                  className={field}
                />
              </div>
              <input
                placeholder="Phone (optional)"
                aria-label="Phone"
                className={`${field} mt-5`}
              />
              <textarea
                required
                rows={5}
                placeholder="How can we help with your stay?"
                aria-label="Message"
                className={`${field} mt-5 resize-none`}
              />
              <div className="mt-7 flex flex-wrap items-center gap-5">
                <MagneticButton type="submit">
                  <Send className="h-3.5 w-3.5" /> Send Enquiry
                </MagneticButton>
                {sent ? (
                  <motion.span
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="text-[0.66rem] tracking-[0.22em] text-[var(--gold)] uppercase"
                  >
                    Thank you — we'll be in touch shortly.
                  </motion.span>
                ) : null}
              </div>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
