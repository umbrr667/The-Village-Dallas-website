import { useState } from "react";
import { motion } from "motion/react";
import { CalendarDays, Search, Users, BedDouble } from "lucide-react";
import { Reveal, MagneticButton } from "./primitives";
import { ROOM_TYPES } from "@/lib/village";

const field =
  "w-full rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white/85 outline-none transition-colors focus:border-[oklch(0.82_0.12_85/55%)]";
const label =
  "mb-2 flex items-center gap-2 text-[0.62rem] tracking-[0.28em] text-white/45 uppercase";

export function VillageBooking() {
  const [status, setStatus] = useState<string | null>(null);

  return (
    <section id="booking" className="relative z-20 -mt-16 px-5 sm:-mt-20">
      <Reveal className="mx-auto max-w-6xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setStatus("Searching availability — a reservations host will confirm shortly.");
          }}
          className="lux-glass rounded-[2rem] p-6 shadow-[0_40px_120px_-50px_oklch(0_0_0/95%)] sm:p-8"
        >
          <div className="grid gap-5 lg:grid-cols-[repeat(4,minmax(0,1fr))_auto] lg:items-end">
            <div>
              <span className={label}>
                <CalendarDays className="h-3.5 w-3.5 text-[var(--gold)]" /> Check-in
              </span>
              <input type="date" required className={field} aria-label="Check-in date" />
            </div>
            <div>
              <span className={label}>
                <CalendarDays className="h-3.5 w-3.5 text-[var(--gold)]" /> Check-out
              </span>
              <input type="date" required className={field} aria-label="Check-out date" />
            </div>
            <div>
              <span className={label}>
                <Users className="h-3.5 w-3.5 text-[var(--gold)]" /> Guests
              </span>
              <select defaultValue="2" className={field} aria-label="Guests">
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <option key={n} value={n} className="bg-[oklch(0.16_0.006_60)]">
                    {n} {n === 1 ? "Guest" : "Guests"}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <span className={label}>
                <BedDouble className="h-3.5 w-3.5 text-[var(--gold)]" /> Room type
              </span>
              <select className={field} aria-label="Room type">
                {["Any residence", ...ROOM_TYPES].map((r) => (
                  <option key={r} className="bg-[oklch(0.16_0.006_60)]">
                    {r}
                  </option>
                ))}
              </select>
            </div>
            <MagneticButton type="submit" className="w-full lg:w-auto">
              <Search className="h-3.5 w-3.5" /> Search
            </MagneticButton>
          </div>

          {status ? (
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-5 text-center text-xs tracking-[0.14em] text-[var(--gold)] uppercase"
            >
              {status}
            </motion.p>
          ) : null}
        </form>
      </Reveal>
    </section>
  );
}
