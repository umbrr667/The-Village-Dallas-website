import { motion } from "motion/react";
import { Reveal, SectionHeading } from "./primitives";
import { EXPERIENCES } from "@/lib/village";

export function VillageExperiences() {
  return (
    <section id="experiences" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Experiences"
          title="Curated by the house"
          subtitle="A rotating calendar reserved for guests and residents — small in scale, generous in spirit."
        />

        <div className="grid gap-6 sm:grid-cols-2">
          {EXPERIENCES.map((e, i) => (
            <Reveal key={e.title} delay={i * 0.08}>
              <motion.div
                whileHover={{ y: -8 }}
                transition={{ type: "spring", stiffness: 230, damping: 21 }}
                className="lux-glass group relative h-full overflow-hidden rounded-[1.75rem] p-8 transition-colors duration-500 hover:border-[oklch(0.82_0.12_85/40%)]"
              >
                <span
                  aria-hidden
                  className="font-serif-lux absolute -top-5 right-5 text-8xl text-white/[0.04] transition-colors duration-700 group-hover:text-[oklch(0.82_0.12_85/12%)]"
                >
                  {String(i + 1).padStart(2, "0")}
                </span>
                <p className="text-[0.62rem] tracking-[0.3em] text-[var(--gold)] uppercase">
                  {e.meta}
                </p>
                <h3 className="font-serif-lux mt-4 text-2xl font-light sm:text-3xl">{e.title}</h3>
                <p className="mt-3 max-w-sm text-sm leading-relaxed font-light text-white/60">
                  {e.copy}
                </p>
                <div className="gold-rule mt-6 w-12 transition-all duration-700 group-hover:w-32" />
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
