import { motion, useInView } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { Reveal, SectionHeading, ImageReveal } from "./primitives";
import { AMENITY_LIST } from "@/lib/village";
import galleryLobby from "@/assets/village/gallery-lobby.jpg";

function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  const [v, setV] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let frame = 0;
    const total = 70;
    const id = setInterval(() => {
      frame += 1;
      const p = 1 - Math.pow(1 - frame / total, 3);
      setV(Math.round(to * p));
      if (frame >= total) clearInterval(id);
    }, 22);
    return () => clearInterval(id);
  }, [inView, to]);

  return (
    <span ref={ref}>
      {v}
      {suffix}
    </span>
  );
}

const STATS = [
  { to: 24, suffix: "/7", label: "Concierge" },
  { to: 12, suffix: "", label: "Acres of green" },
  { to: 6, suffix: "", label: "Dining venues" },
  { to: 98, suffix: "%", label: "Guest satisfaction" },
];

export function VillageAbout() {
  return (
    <section id="about" className="relative px-5 py-28 sm:py-36">
      <div className="mx-auto grid max-w-6xl items-center gap-14 lg:grid-cols-2">
        <Reveal>
          <div className="relative">
            <ImageReveal
              src={galleryLobby}
              alt="Warmly lit lobby lounge at The Village Dallas"
              className="animate-lux-float aspect-[4/5] rounded-[2rem]"
            />
            <div className="lux-glass absolute -right-4 -bottom-6 hidden rounded-2xl px-6 py-5 sm:block">
              <p className="font-serif-lux text-3xl gold-text">Est. 1970</p>
              <p className="mt-1 text-[0.6rem] tracking-[0.3em] text-white/50 uppercase">
                Reimagined 2026
              </p>
            </div>
          </div>
        </Reveal>

        <div>
          <SectionHeading
            align="left"
            eyebrow="The Village"
            title="A resort that happens to be a neighbourhood"
            subtitle="Set across twelve landscaped acres between Greenville Avenue and the Katy Trail, The Village pairs the intimacy of residential living with the polish of a five-star hotel. Stay a night, a season, or make it home."
            className="mb-8"
          />
          <Reveal delay={0.1}>
            <div className="grid grid-cols-2 gap-x-6 gap-y-3">
              {AMENITY_LIST.map((a) => (
                <motion.div
                  key={a}
                  whileHover={{ x: 5 }}
                  className="flex items-center gap-3 border-b border-white/[0.07] py-3 text-sm font-light text-white/65"
                >
                  <span className="h-1 w-1 rounded-full bg-[var(--gold)]" />
                  {a}
                </motion.div>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-4">
              {STATS.map((s) => (
                <div key={s.label}>
                  <p className="font-serif-lux text-3xl gold-text">
                    <Counter to={s.to} suffix={s.suffix} />
                  </p>
                  <p className="mt-1 text-[0.6rem] tracking-[0.24em] text-white/45 uppercase">
                    {s.label}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
