import roomSignature from "@/assets/village/room-signature.jpg";
import roomTerrace from "@/assets/village/room-terrace.jpg";
import roomPenthouse from "@/assets/village/room-penthouse.jpg";
import amenityPool from "@/assets/village/amenity-pool.jpg";
import amenitySpa from "@/assets/village/amenity-spa.jpg";
import amenityGym from "@/assets/village/amenity-gym.jpg";
import diningRestaurant from "@/assets/village/dining-restaurant.jpg";
import diningBar from "@/assets/village/dining-bar.jpg";
import galleryLobby from "@/assets/village/gallery-lobby.jpg";
import galleryExterior from "@/assets/village/hero-night.jpg";

export const HOTEL = {
  name: "The Village Dallas",
  tagline: "Experience Luxury Living at The Village Dallas",
  address: "5605 Village Glen Drive, Dallas, TX 75206",
  phone: "+1 (214) 363-3300",
  email: "reservations@thevillagedallas.com",
  mapUrl: "https://maps.google.com/?q=5605+Village+Glen+Drive+Dallas+TX+75206",
  note: "Concept redesign — imagery and details are illustrative.",
};

export const NAV = [
  { label: "About", href: "#about" },
  { label: "Rooms", href: "#rooms" },
  { label: "Amenities", href: "#amenities" },
  { label: "Dining", href: "#dining" },
  { label: "Gallery", href: "#gallery" },
  { label: "Experiences", href: "#experiences" },
  { label: "Location", href: "#location" },
  { label: "Contact", href: "#contact" },
];

export const ROOMS = [
  {
    id: "signature",
    name: "Signature King Suite",
    image: roomSignature,
    price: 385,
    size: "620 sq ft",
    guests: "2 Guests",
    blurb:
      "Warm oak, brushed brass and floor-to-ceiling glass framing the Village skyline.",
    features: ["King bed", "Rainfall shower", "Smart lighting", "Nespresso bar", "Skyline view"],
  },
  {
    id: "terrace",
    name: "Terrace Garden Residence",
    image: roomTerrace,
    price: 520,
    size: "890 sq ft",
    guests: "3 Guests",
    blurb:
      "A private landscaped terrace, sunken lounge and soaking tub carved from Carrara stone.",
    features: ["Private terrace", "Soaking tub", "Chef kitchenette", "Fireplace", "Garden view"],
  },
  {
    id: "penthouse",
    name: "The Glen Penthouse",
    image: roomPenthouse,
    price: 940,
    size: "1,480 sq ft",
    guests: "4 Guests",
    blurb:
      "Two levels of cinematic living with a rooftop plunge pool and dedicated house attaché.",
    features: ["Plunge pool", "House attaché", "Wine vault", "Dining for 8", "Panoramic views"],
  },
];

export const AMENITIES = [
  {
    title: "Rooftop Infinity Pool",
    image: amenityPool,
    copy: "A heated 25-metre infinity edge suspended above the treeline, with cabana service until midnight.",
  },
  {
    title: "The Glen Spa",
    image: amenitySpa,
    copy: "Six treatment suites, a marble hammam and a botanical relaxation garden.",
  },
  {
    title: "Athletic Club",
    image: amenityGym,
    copy: "24-hour training floor, reformer studio and private coaching from Dallas' best.",
  },
];

export const AMENITY_LIST = [
  "24-hour concierge",
  "Valet parking",
  "Pet-friendly residences",
  "Co-working lounge",
  "Screening room",
  "Resident events",
  "Bike & trail access",
  "Smart-home controls",
];

export const DINING = [
  {
    name: "Glen & Oak",
    image: diningRestaurant,
    kind: "Seasonal American",
    hours: "Dinner · 5:30 – 11:00 pm",
    copy: "Hearth-fired Texas produce, an oak-panelled room and a 900-label cellar.",
  },
  {
    name: "Bar Lumière",
    image: diningBar,
    kind: "Cocktails & Small Plates",
    hours: "Daily · 4:00 pm – late",
    copy: "Low light, high craft. Aged negronis, caviar service and live vinyl on weekends.",
  },
];

export const GALLERY = [
  { src: galleryLobby, alt: "The Village Dallas lobby with warm lighting", span: "lg:row-span-2" },
  { src: roomPenthouse, alt: "Penthouse living space", span: "" },
  { src: amenityPool, alt: "Rooftop infinity pool at dusk", span: "" },
  { src: galleryExterior, alt: "Illuminated hotel exterior at night", span: "lg:col-span-2" },
  { src: diningBar, alt: "Cocktail bar interior", span: "" },
  { src: amenitySpa, alt: "Spa relaxation suite", span: "" },
  { src: roomTerrace, alt: "Terrace residence with private garden", span: "lg:col-span-2" },
  { src: diningRestaurant, alt: "Restaurant dining room", span: "" },
];

export const EXPERIENCES = [
  {
    title: "Sunset Rooftop Sessions",
    copy: "Live strings, chilled champagne and the Dallas skyline turning gold.",
    meta: "Thursdays · Rooftop",
  },
  {
    title: "Chef's Table at Glen & Oak",
    copy: "Eight seats, nine courses, one fire. Booked one month in advance.",
    meta: "Fridays · 12 seats",
  },
  {
    title: "Village Trail Mornings",
    copy: "Guided run along Katy Trail followed by recovery in the hammam.",
    meta: "Daily · 6:30 am",
  },
  {
    title: "Curated Art Walks",
    copy: "Private access to the Dallas Arts District with a resident curator.",
    meta: "Monthly · Limited",
  },
];

export const REVIEWS = [
  {
    name: "Amelia R.",
    role: "Travelled for business",
    quote:
      "The most considered stay I've had in Texas. The attaché anticipated everything before I asked.",
  },
  {
    name: "Daniel & Sofia",
    role: "Anniversary weekend",
    quote:
      "The terrace residence felt like a private villa in the middle of the city. We never left.",
  },
  {
    name: "Marcus L.",
    role: "Long-stay resident",
    quote:
      "Rooftop pool, an actual chef downstairs and the Katy Trail at the door. Impossible to beat.",
  },
];

export const FAQS = [
  {
    q: "What time is check-in and check-out?",
    a: "Check-in opens at 3:00 pm and check-out is at 12:00 pm. Early arrival and late departure can be arranged with the concierge, subject to availability.",
  },
  {
    q: "Is parking available on site?",
    a: "Yes. Complimentary self-parking and 24-hour valet are available for all guests and residents.",
  },
  {
    q: "Are pets welcome?",
    a: "Very. The Village is pet-friendly with on-site green space, a grooming suite and a resident dog park.",
  },
  {
    q: "Do you host events or private dining?",
    a: "Glen & Oak offers a private dining room for up to 22 guests, and the rooftop can be reserved for celebrations of up to 120.",
  },
  {
    q: "What is the cancellation policy?",
    a: "Reservations may be cancelled at no charge up to 48 hours before arrival. Peak-season and penthouse bookings require 7 days' notice.",
  },
];

export const ROOM_TYPES = ROOMS.map((r) => r.name);
