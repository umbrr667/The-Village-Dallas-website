/**
 * Official technology logos, served from the Simple Icons CDN in brand colours.
 * `undefined` entries fall back to a lettered glass tile in the UI.
 */

export type TechLogo = {
  name: string;
  slug?: string;
  /** Absolute logo URL used when Simple Icons has no matching slug. */
  src?: string;
  color?: string;
  note: string;
};

function url(slug: string, color?: string) {
  return `https://cdn.simpleicons.org/${slug}${color ? `/${color}` : ""}`;
}

export const TECH_LOGOS: TechLogo[] = [
  { name: "Python", slug: "python", note: "Core language for every automation I build." },
  { name: "HTML", slug: "html5", note: "Semantic structure for responsive websites." },
  { name: "CSS", slug: "css", note: "Mobile-first styling and layout." },
  { name: "JavaScript", slug: "javascript", note: "Interactivity for web projects." },
  { name: "React", slug: "react", note: "Component-driven interfaces." },
  { name: "TypeScript", slug: "typescript", note: "Type-safe front-end code." },
  { name: "Tailwind CSS", slug: "tailwindcss", note: "Utility-first design system." },
  { name: "Streamlit", slug: "streamlit", note: "Fast UIs for my Python AI tools." },
  { name: "LangChain", slug: "langchain", color: "ffffff", note: "Chains and retrieval over documents." },
  { name: "Groq API", note: "Ultra-fast LLM inference." },
  { name: "Git", slug: "git", note: "Version control on every project." },
  { name: "GitHub", slug: "github", color: "ffffff", note: "Where all of my code lives." },
  {
    name: "VS Code",
    src: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg",
    note: "Daily development environment.",
  },
  { name: "Vercel", slug: "vercel", color: "ffffff", note: "Deployment for web projects." },
  { name: "Lovable", note: "AI-assisted product and web builds." },
];

type LogoRef = { slug?: string | undefined; color?: string | undefined; src?: string | undefined };

const bySlug: Record<string, LogoRef> = Object.fromEntries(
  TECH_LOGOS.map((t) => [t.name.toLowerCase(), { slug: t.slug, color: t.color, src: t.src }]),
);

/** Extra aliases used by project tech lists. */
const aliases: Record<string, LogoRef> = {

  "llm apis": { slug: "openai", color: "ffffff" },
  "ai voice apis": { slug: "elevenlabs", color: "ffffff" },
  pypdf: { slug: "adobeacrobatreader" },
  "prompt engineering": {},
  "workflow automation": {},
  "api integration": {},
  "ai email automation": { slug: "gmail" },
};

export function logoUrl(tech: string): string | undefined {
  const key = tech.toLowerCase();
  const hit = bySlug[key] ?? aliases[key];
  if (hit?.src) return hit.src;
  return hit?.slug ? url(hit.slug, hit.color) : undefined;
}
