/**
 * Single source of truth for all portfolio content.
 * Every value here is taken directly from Umbar Gul Naz's CV / uploaded files.
 * Do not add information that is not present in the CV.
 */

import portrait from "@/assets/portrait.asset.json";
import resumeAsset from "@/assets/resume.asset.json";
import vidChat from "@/assets/vid-chat.asset.json";
import vidApi from "@/assets/vid-api.asset.json";
import imgEmail from "@/assets/img-email.asset.json";
import imgDoc from "@/assets/img-doc.asset.json";
import imgChatbot from "@/assets/img-chatbot.asset.json";
import imgSocial from "@/assets/img-social.asset.json";
import imgWorkflow from "@/assets/img-workflow.asset.json";
import imgVoice from "@/assets/img-voice.asset.json";
import imgWeb from "@/assets/img-web.asset.json";
import imgCalc from "@/assets/img-calc.asset.json";

export const GITHUB_URL = "https://github.com/umbrr667";
export const LINKEDIN_URL = "https://www.linkedin.com/in/umbar-gul-naz-6aa6b6310";
export const EMAIL = "umbargul13@gmail.com";
export const PHONE = "03442756954";
export const WHATSAPP_URL = "https://wa.me/923442756954";
export const RESUME_URL = resumeAsset.url;
export const PORTRAIT_URL = portrait.url;

export const NAME = "Umbar Gul Naz";
export const ROLE =
  "AI Automation Engineer | Computer Engineering Student | AI Enthusiast";
export const INTRO =
  "I help businesses automate customer support, workflows, communication and operations using AI, LLMs and Python.";

export const SUMMARY =
  "AI Automation Engineer and Computer Engineering student at UET Taxila, focused on building practical AI chatbots, AI voice agents, and LLM-powered automation tools with Python.";

export const TYPING_PHRASES = [
  "Building AI Solutions",
  "AI Chatbots",
  "AI Voice Agents",
  "Business Automation",
  "Python Automation",
  "LLM Applications",
  "Prompt Engineering",
];

export const SKILL_GROUPS = [
  {
    title: "Programming",
    icon: "code",
    tone: "primary" as const,
    items: ["Python", "HTML", "CSS", "JavaScript"],
  },
  {
    title: "Artificial Intelligence",
    icon: "brain",
    tone: "secondary" as const,
    items: [
      "AI Automation",
      "Prompt Engineering",
      "LLM Applications",
      "AI Chatbots",
      "AI Voice Agents",
      "AI Email Automation",
      "Document Intelligence",
      "Business Automation",
    ],
  },
  {
    title: "Frameworks & Libraries",
    icon: "layers",
    tone: "accent" as const,
    items: ["Streamlit", "LangChain", "Groq API", "PyPDF"],
  },
  {
    title: "Developer Tools",
    icon: "wrench",
    tone: "primary" as const,
    items: ["Git", "GitHub", "VS Code", "Lovable", "Google Workspace", "Microsoft Office"],
  },
];

export const TECH_ORBITS = [
  {
    radius: 118,
    duration: 30,
    items: [
      { name: "Python", note: "Primary language for every AI automation I build." },
      { name: "Groq API", note: "Fast LLM inference powering my chat and email tools." },
      { name: "LangChain", note: "Chains and retrieval pipelines over PDF content." },
    ],
  },
  {
    radius: 192,
    duration: 46,
    items: [
      { name: "Streamlit", note: "Interactive front ends for my document intelligence apps." },
      { name: "PyPDF", note: "PDF parsing and text extraction for Q&A bots." },
      { name: "Prompt Engineering", note: "Prompt logic that keeps tone and answers accurate." },
      { name: "JavaScript", note: "Interactivity for business websites and landing pages." },
    ],
  },
  {
    radius: 264,
    duration: 66,
    items: [
      { name: "HTML", note: "Semantic structure for responsive business websites." },
      { name: "CSS", note: "Clean, mobile-first styling and layout." },
      { name: "Git", note: "Version control across every project." },
      { name: "GitHub", note: "Where all of my project code lives." },
      { name: "VS Code", note: "Daily development environment." },
      { name: "Lovable", note: "AI-assisted product and web builds." },
    ],
  },
];

export type Project = {
  id: string;
  title: string;
  tag: string;
  image: string;
  video?: string;
  duration?: string;
  summary: string;
  problem: string;
  overview: string;
  tech: string[];
  features: string[];
};

export const PROJECTS: Project[] = [
  {
    id: "doc-summarizer",
    title: "AI Document Summarizer & Q&A Bot",
    tag: "Document Intelligence",
    image: imgDoc.url,
    summary:
      "Upload a PDF, get a concise summary, then ask follow-up questions about the document.",
    problem:
      "Teams and students lose hours reading long PDFs to find a handful of answers.",
    overview:
      "A document intelligence tool that lets users upload PDFs, generate concise summaries, and ask follow-up questions through an interactive Streamlit interface. LangChain pipelines with the Groq API handle accurate LLM-based question answering over the PDF content.",
    tech: ["Python", "Streamlit", "LangChain", "Groq API", "PyPDF"],
    features: [
      "PDF upload with instant text extraction",
      "Concise AI-generated document summaries",
      "Follow-up Q&A over the uploaded content",
      "Interactive Streamlit interface",
    ],
  },
  {
    id: "email-responder",
    title: "AI Email Responder",
    tag: "Email Automation",
    image: imgEmail.url,
    summary:
      "Generates context-aware, professional email replies with classified intent.",
    problem:
      "Support inboxes fill up with repetitive customer emails that each need a careful, on-brand reply.",
    overview:
      "An AI-powered email response generator built with Python and the Groq API. It reads an incoming customer email, classifies it, and produces a context-aware professional reply, using prompt engineering to keep tone and content accurate.",
    tech: ["Python", "Groq API", "Prompt Engineering"],
    features: [
      "Automatic email category classification",
      "Context-aware professional reply drafting",
      "Prompt engineering for consistent tone",
      "Runs on fast Groq LLM inference",
    ],
  },
  {
    id: "support-chatbot",
    title: "AI Customer Support Chatbot",
    tag: "Conversational AI",
    image: imgChatbot.url,
    video: vidChat.url,
    duration: "Demo video",
    summary:
      "Conversational chatbot that answers business customer queries automatically.",
    problem:
      "Businesses cannot staff live support around the clock, so routine customer questions go unanswered.",
    overview:
      "A conversational chatbot developed in Python with LLM APIs that automatically answers business-related customer queries. Prompt logic is designed for accurate, relevant responses so the assistant stays on-topic and useful.",
    tech: ["Python", "LLM APIs", "Prompt Engineering"],
    features: [
      "Automated answers to business queries",
      "Prompt logic tuned for relevance and accuracy",
      "Handles repeated support conversations",
      "Built for customer-facing use",
    ],
  },
  {
    id: "social-generator",
    title: "AI Social Media Content Generator",
    tag: "Content Automation",
    image: imgSocial.url,
    summary:
      "Generates AI-powered captions, product descriptions and marketing content.",
    problem:
      "Small businesses need a steady stream of on-brand social content but have no time to write it.",
    overview:
      "A Python tool built on LLM APIs that generates captions, product descriptions and marketing content. Prompt engineering matches the tone and format to the platform the content is written for.",
    tech: ["Python", "LLM APIs", "Prompt Engineering"],
    features: [
      "AI caption and copy generation",
      "Product description writing",
      "Tone and platform matching via prompts",
      "Reusable marketing content output",
    ],
  },
  {
    id: "voice-agent",
    title: "AI Voice Agent (Demo)",
    tag: "Voice AI",
    image: imgVoice.url,
    summary:
      "Demo AI receptionist exploring voice-based conversational AI for businesses.",
    problem:
      "Routine phone interactions such as reception and basic support take staff away from higher value work.",
    overview:
      "A demo AI-powered receptionist built in Python with AI voice and LLM APIs, exploring voice-based conversational AI for customer support and business automation of routine interactions.",
    tech: ["Python", "AI Voice APIs", "LLM APIs"],
    features: [
      "Voice-based conversational flow",
      "Receptionist-style customer handling",
      "Routine interaction automation",
      "Built as a working demo",
    ],
  },
  {
    id: "business-website",
    title: "Business Website Development",
    tag: "Web",
    image: imgWeb.url,
    summary: "Responsive landing pages and business websites with clean, mobile-first UI.",
    problem:
      "Small businesses need a fast, credible web presence that works properly on mobile.",
    overview:
      "Designed and built responsive landing pages and business websites with HTML, CSS and JavaScript, focused on clean UI and mobile usability.",
    tech: ["HTML", "CSS", "JavaScript"],
    features: [
      "Responsive landing page layouts",
      "Mobile-first usability",
      "Clean, readable UI",
      "Lightweight, fast-loading pages",
    ],
  },
  {
    id: "calculator",
    title: "Calculator Web Application",
    tag: "Web",
    image: imgCalc.url,
    summary: "Fully functional, responsive calculator built with AI-assisted development.",
    problem:
      "A focused exercise in building a fully working, responsive interactive web app from scratch.",
    overview:
      "A fully functional, responsive calculator application built with HTML, CSS and JavaScript using AI-assisted development.",
    tech: ["HTML", "CSS", "JavaScript"],
    features: [
      "Complete arithmetic operations",
      "Responsive on all screen sizes",
      "Keyboard and click input",
      "Built with AI-assisted development",
    ],
  },
];

export type Demo = {
  id: string;
  title: string;
  video: string;
  poster: string;
  duration: string;
  description: string;
  problem: string;
  overview: string;
  tech: string[];
  features: string[];
};

export const DEMOS: Demo[] = [
  {
    id: "chat-automation",
    title: "AI Chat Automation System",
    video: vidChat.url,
    poster: imgChatbot.url,
    duration: "Video demo",
    description:
      "Live walkthrough of the AI customer support chatbot answering business queries in conversation.",
    problem:
      "Businesses cannot answer every routine customer question manually, at every hour.",
    overview:
      "A recorded walkthrough of the AI Customer Support Chatbot: a Python conversational assistant built on LLM APIs that automatically answers business-related customer queries, with prompt logic designed for accurate, relevant responses.",
    tech: ["Python", "LLM APIs", "Prompt Engineering"],
    features: [
      "Automated conversational support",
      "Business query handling",
      "Prompt-controlled response accuracy",
      "Customer-facing chat interface",
    ],
  },
  {
    id: "api-automation",
    title: "API Integration & Workflow Automation",
    video: vidApi.url,
    poster: imgWorkflow.url,
    duration: "Video demo",
    description:
      "Walkthrough of an automated workflow moving data between services and triggering email.",
    problem:
      "Manual copying of form and spreadsheet data into email and other tools wastes hours every week.",
    overview:
      "A recorded walkthrough of a workflow automation that watches new rows of incoming data and triggers an automated email response, connecting services through API integration so routine business communication runs without manual work.",
    tech: ["Workflow Automation", "API Integration", "AI Email Automation"],
    features: [
      "Trigger on new incoming data",
      "Service-to-service API integration",
      "Automated email dispatch",
      "Repeatable, scheduled runs",
    ],
  },
];

export const SERVICES = [
  { title: "AI Chatbots", icon: "bot", desc: "Conversational assistants that answer business and customer queries automatically." },
  { title: "AI Voice Agents", icon: "mic", desc: "Voice-based receptionists and assistants for routine customer interactions." },
  { title: "AI Email Automation", icon: "mail", desc: "Context-aware, professional email replies generated and classified with AI." },
  { title: "Document Intelligence", icon: "fileText", desc: "PDF summarization and Q&A over your documents with LangChain and Groq." },
  { title: "Workflow Automation", icon: "workflow", desc: "Automated pipelines that move data between tools and trigger actions." },
  { title: "Business Automation", icon: "building", desc: "Automating repetitive operational and communication tasks end to end." },
  { title: "Landing Pages", icon: "layout", desc: "Focused, fast landing pages built to present an offer clearly." },
  { title: "Responsive Websites", icon: "monitor", desc: "Clean, mobile-first business websites in HTML, CSS and JavaScript." },
  { title: "Prompt Engineering", icon: "sparkles", desc: "Prompt systems that keep AI output accurate, on-tone and reliable." },
  { title: "LLM Applications", icon: "brain", desc: "Practical Python applications built on top of large language models." },
];

export const WORKFLOW_STEPS = [
  { title: "Discovery", desc: "Understand the business process and the exact task to automate." },
  { title: "Planning", desc: "Define scope, inputs, outputs and how success will be measured." },
  { title: "Prompt Engineering", desc: "Design and test the prompt logic that controls AI behaviour." },
  { title: "AI Architecture", desc: "Choose the model, framework and data flow for the solution." },
  { title: "Development", desc: "Build the application in Python with the chosen AI stack." },
  { title: "Testing", desc: "Validate accuracy, tone and edge cases against real inputs." },
  { title: "Deployment", desc: "Ship the working tool so the business can actually use it." },
  { title: "Support", desc: "Refine prompts and behaviour based on real usage feedback." },
];

export const CERTIFICATIONS = [
  { title: "Python Programming & Training", issuer: "Arch Technologies", detail: "8 Weeks" },
  { title: "AI Automation & Prompt Engineering", issuer: "AI Abdanix Solutions", detail: "Certification" },
  { title: "Social Media Marketing", issuer: "Nova Science Academy, Layyah", detail: "Certification" },
  { title: "Graphic Designing", issuer: "DigiSkills Pakistan", detail: "Certification" },
];

export const LEADERSHIP = [
  "British Parliamentary Debate Competitor",
  "Secured 2nd Position in one British Parliamentary Debate round",
  "Secured 4th Position in another British Parliamentary Debate round",
  "Hosted university events and technical sessions",
  "Participated in the Young Policy Leaders Program",
  "Strong Public Speaking",
  "Team Collaboration",
];

export const SOFT_SKILLS = [
  "Communication",
  "Leadership",
  "Problem Solving",
  "Critical Thinking",
  "Public Speaking",
  "Teamwork",
  "Adaptability",
  "Time Management",
];

export const RESUME_HIGHLIGHTS = [
  {
    label: "Education",
    lines: [
      "BSc Computer Engineering — University of Engineering & Technology, Taxila",
      "Intermediate (Pre-Engineering) — Punjab Group of Colleges",
    ],
  },
  {
    label: "Focus",
    lines: [
      "AI Automation, AI Chatbots & Voice Agents",
      "Prompt Engineering and LLM applications",
      "Python automation and workflow integration",
    ],
  },
  {
    label: "Selected work",
    lines: [
      "AI Email Responder — automated, context-aware replies",
      "AI Customer Support Chatbot — 24/7 business assistant",
      "AI Document Summarizer & Q&A Bot — LangChain + Groq",
      "AI Social Media Content Generator",
    ],
  },
  {
    label: "Certifications",
    lines: [
      "Python Programming & Training — Arch Technologies",
      "AI Automation & Prompt Engineering — AI Abdanix Solutions",
      "Social Media Marketing — Nova Science Academy",
      "Graphic Designing — DigiSkills Pakistan",
    ],
  },
];


export const NAV_LINKS = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Tech", href: "#technologies" },
  { label: "Projects", href: "#projects" },
  { label: "Live Demos", href: "#demos" },
  { label: "Resume", href: "#resume" },
  { label: "Leadership", href: "#leadership" },
  { label: "Contact", href: "#contact" },
];
